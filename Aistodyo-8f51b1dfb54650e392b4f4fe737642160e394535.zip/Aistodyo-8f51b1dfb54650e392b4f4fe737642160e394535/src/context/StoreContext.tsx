import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Product,
  Order,
  FinancialTransaction,
  Ad,
  StoreSettings,
  PasswordResetRequest,
  OrderStatus,
  PaymentMethod,
  Address
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_PRODUCTS,
  INITIAL_ADS,
  INITIAL_SETTINGS,
  INITIAL_ORDERS,
  INITIAL_TRANSACTIONS
} from '../data/initialData';
import { audioAlert } from '../utils/audioAlert';

interface CartItem {
  product: Product;
  quantity: number;
}

interface StoreContextType {
  currentUser: User | null;
  users: User[];
  products: Product[];
  orders: Order[];
  transactions: FinancialTransaction[];
  ads: Ad[];
  settings: StoreSettings;
  resetRequests: PasswordResetRequest[];
  cart: CartItem[];
  isSirenRinging: boolean;
  activeAlertOrder: Order | null;

  // Auth
  login: (email: string, password?: string) => { success: boolean; error?: string; user?: User };
  register: (userData: Partial<User>) => { success: boolean; error?: string; user?: User };
  logout: () => void;
  requestPasswordReset: (phone: string) => { success: boolean; message: string };
  resolvePasswordReset: (requestId: string, temporaryPassword?: string) => string;

  // Cart
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => { subtotal: number; deliveryFee: number; total: number };

  // Orders
  createOrder: (orderData: {
    customerName: string;
    customerPhone: string;
    customerAddress: Address;
    paymentMethod: PaymentMethod;
    notes?: string;
  }) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  assignDriverToOrder: (orderId: string, driverName: string, driverPhone: string) => string;
  cancelOrder: (orderId: string, reason?: string) => void;

  // Merchant / Products
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Product;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  toggleHideProduct: (id: string) => void;

  // Trader Management & Debt
  banTrader: (traderId: string, reason: string, resolutionSteps: string) => string;
  unbanTrader: (traderId: string) => void;
  zeroTraderDebt: (traderId: string, notes?: string) => void;

  // Customer Management
  banCustomer: (customerId: string, reason?: string) => void;
  unbanCustomer: (customerId: string) => void;
  deleteUser: (userId: string) => void;
  addOrUpdateUser: (userData: Partial<User>) => User;

  // Ads
  addAd: (ad: Omit<Ad, 'id'>) => Ad;
  updateAd: (id: string, ad: Partial<Ad>) => void;
  deleteAd: (id: string) => void;

  // Settings
  updateSettings: (newSettings: Partial<StoreSettings>) => void;

  // Siren
  stopSiren: () => void;
  testSiren: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEY = 'baladi_store_v3';

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load from localStorage or use initial seed
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_users`);
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_current_user`);
    return saved ? JSON.parse(saved) : null;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_products`);
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_orders`);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [transactions, setTransactions] = useState<FinancialTransaction[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_transactions`);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [ads, setAds] = useState<Ad[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_ads`);
    return saved ? JSON.parse(saved) : INITIAL_ADS;
  });

  const [settings, setSettings] = useState<StoreSettings>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_settings`);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [resetRequests, setResetRequests] = useState<PasswordResetRequest[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_resets`);
    return saved ? JSON.parse(saved) : [];
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY}_cart`);
    return saved ? JSON.parse(saved) : [];
  });

  const [isSirenRinging, setIsSirenRinging] = useState(false);
  const [activeAlertOrder, setActiveAlertOrder] = useState<Order | null>(null);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`${STORAGE_KEY}_current_user`, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(`${STORAGE_KEY}_current_user`);
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_products`, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_orders`, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_transactions`, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_ads`, JSON.stringify(ads));
  }, [ads]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_resets`, JSON.stringify(resetRequests));
  }, [resetRequests]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_cart`, JSON.stringify(cart));
  }, [cart]);

  // Auth Methods
  const login = (email: string, password?: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = password?.trim();

    const user = users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      return { success: false, error: 'البريد الإلكتروني غير مسجل في النظام' };
    }

    if (user.isBanned) {
      return {
        success: false,
        error: `هذا الحساب محظور حالياً. سبب الحظر: ${user.banReason || 'مخالفة الشروط والأحكام'}`
      };
    }

    if (user.password && user.password !== cleanPass) {
      return { success: false, error: 'كلمة المرور غير صحيحة، يرجى المحاولة مرة أخرى أو طلب استعادة كلمة المرور' };
    }

    setCurrentUser(user);
    return { success: true, user };
  };

  const register = (userData: Partial<User>) => {
    if (!userData.email || !userData.phone || !userData.name) {
      return { success: false, error: 'يرجى استكمال جميع البيانات الأساسية المطلوبة' };
    }

    const emailExists = users.some(u => u.email.toLowerCase() === userData.email!.trim().toLowerCase());
    if (emailExists) {
      return { success: false, error: 'البريد الإلكتروني مسجل بالفعل' };
    }

    const phoneExists = users.some(u => u.phone.trim() === userData.phone!.trim());
    if (phoneExists) {
      return { success: false, error: 'رقم الهاتف مسجل لحساب آخر بالفعل' };
    }

    const newUser: User = {
      id: `usr_${Date.now()}`,
      name: userData.name.trim(),
      phone: userData.phone.trim(),
      email: userData.email.trim().toLowerCase(),
      password: userData.password?.trim() || '123456',
      role: userData.role || 'customer',
      address: userData.address || {
        governorate: 'القاهرة',
        cityOrDistrict: '',
        street: '',
        building: '',
        landmark: ''
      },
      storeName: userData.storeName,
      debt: 0,
      totalSales: 0,
      balance: 0,
      isApproved: userData.role === 'customer' ? true : false,
      createdAt: new Date().toISOString()
    };

    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    return { success: true, user: newUser };
  };

  const logout = () => {
    stopSiren();
    setCurrentUser(null);
  };

  const requestPasswordReset = (phone: string) => {
    const cleanPhone = phone.trim();
    const user = users.find(u => u.phone === cleanPhone);

    const newRequest: PasswordResetRequest = {
      id: `reset_${Date.now()}`,
      phone: cleanPhone,
      userName: user?.name || 'مستخدم بالهاتف',
      userEmail: user?.email,
      userRole: user?.role || 'customer',
      requestedAt: new Date().toISOString(),
      status: 'pending'
    };

    setResetRequests(prev => [newRequest, ...prev]);
    return {
      success: true,
      message: 'تم إرسال طلب استعادة كلمة المرور للإدارة، وسيتم التواصل معك مباشرة عبر الواتساب لتزويدك ببيانات الدخول.'
    };
  };

  const resolvePasswordReset = (requestId: string, temporaryPassword?: string): string => {
    const req = resetRequests.find(r => r.id === requestId);
    if (!req) return '';

    const newPass = temporaryPassword || `BLD-${Math.floor(100000 + Math.random() * 900000)}`;

    // Update user password if user exists
    if (req.userEmail) {
      setUsers(prev =>
        prev.map(u => (u.email.toLowerCase() === req.userEmail?.toLowerCase() ? { ...u, password: newPass } : u))
      );
    }

    // Mark request resolved
    setResetRequests(prev =>
      prev.map(r =>
        r.id === requestId
          ? {
              ...r,
              status: 'resolved',
              resolvedAt: new Date().toISOString(),
              resolvedBy: currentUser?.name || 'الإدارة'
            }
          : r
      )
    );

    // Build WhatsApp URL
    const message = settings.whatsappTemplates.passwordReset
      .replace('{user_name}', req.userName || 'العميل العزيز')
      .replace('{email}', req.userEmail || req.phone)
      .replace('{password}', newPass)
      .replace('{store_url}', window.location.origin);

    const cleanPhone = req.phone.startsWith('0') ? '2' + req.phone : req.phone;
    const whatsappUrl = `https://wa.me/${cleanPhone.replace(/\+/g, '')}?text=${encodeURIComponent(message)}`;
    return whatsappUrl;
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => setCart([]);

  const getCartTotal = () => {
    const subtotal = cart.reduce((acc, item) => {
      const price = item.product.discountPrice || item.product.price;
      return acc + price * item.quantity;
    }, 0);
    const deliveryFee = subtotal > 0 ? settings.deliveryFee : 0;
    return {
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee
    };
  };

  // Orders
  const createOrder = (orderData: {
    customerName: string;
    customerPhone: string;
    customerAddress: Address;
    paymentMethod: PaymentMethod;
    notes?: string;
  }): Order => {
    const { subtotal, deliveryFee, total } = getCartTotal();
    const orderNum = `BLD-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date().toISOString();

    const orderItems = cart.map(item => ({
      productId: item.product.id,
      name: item.product.name,
      price: item.product.discountPrice || item.product.price,
      quantity: item.quantity,
      unit: item.product.unit,
      traderId: item.product.traderId,
      traderName: item.product.traderName,
      image: item.product.image
    }));

    const uniqueTraderIds = Array.from(new Set(orderItems.map(i => i.traderId)));

    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber: orderNum,
      customerId: currentUser?.id || `guest_${Date.now()}`,
      customerName: orderData.customerName,
      customerPhone: orderData.customerPhone,
      customerAddress: orderData.customerAddress,
      items: orderItems,
      subtotal,
      deliveryFee,
      total,
      paymentMethod: orderData.paymentMethod,
      paymentStatus: orderData.paymentMethod === 'cash' ? 'pending' : 'paid',
      status: 'new',
      notes: orderData.notes,
      createdAt: now,
      updatedAt: now,
      traderIds: uniqueTraderIds
    };

    // 1. Add order
    setOrders(prev => [newOrder, ...prev]);

    // 2. Record Customer Financial Transaction in DB
    const customerTx: FinancialTransaction = {
      id: `tx_${Date.now()}`,
      transactionNumber: `TX-${orderNum}`,
      userId: currentUser?.id || `guest_${Date.now()}`,
      userName: orderData.customerName,
      userRole: 'customer',
      type: 'order_payment',
      amount: total,
      paymentMethod: orderData.paymentMethod,
      orderId: newOrder.id,
      orderNumber: orderNum,
      status: orderData.paymentMethod === 'cash' ? 'pending' : 'completed',
      description: `شراء أصناف بقالة وخضار طازج (طلب ${orderNum})`,
      date: now
    };
    setTransactions(prev => [customerTx, ...prev]);

    // 3. Update Trader Debt & Sales for each trader
    uniqueTraderIds.forEach(tId => {
      const traderItemsTotal = orderItems
        .filter(i => i.traderId === tId)
        .reduce((sum, i) => sum + i.price * i.quantity, 0);

      const commission = (traderItemsTotal * settings.platformCommissionRate) / 100;

      // Update trader record
      setUsers(prev =>
        prev.map(u => {
          if (u.id === tId) {
            return {
              ...u,
              totalSales: (u.totalSales || 0) + traderItemsTotal,
              debt: (u.debt || 0) + commission
            };
          }
          return u;
        })
      );

      // Record platform commission transaction
      const commissionTx: FinancialTransaction = {
        id: `tx_${Date.now()}_com_${tId}`,
        transactionNumber: `TX-${orderNum}-COM`,
        userId: tId,
        userName: orderItems.find(i => i.traderId === tId)?.traderName || 'التاجر',
        userRole: 'trader',
        type: 'commission_deduction',
        amount: commission,
        paymentMethod: 'system_adjustment',
        orderId: newOrder.id,
        orderNumber: orderNum,
        status: 'completed',
        description: `عمولة المنصة (${settings.platformCommissionRate}%) عن طلب #${orderNum}`,
        date: now
      };
      setTransactions(prev => [commissionTx, ...prev]);
    });

    // 4. Trigger Loud Siren Alert ONLY for Merchant (whose items are ordered) or Admin/Supervisor, NOT for customer!
    const isMerchantOfThisOrder =
      currentUser?.role === 'trader' && uniqueTraderIds.includes(currentUser.id);
    const isAdminOrSupervisor =
      currentUser?.role === 'admin' || currentUser?.role === 'supervisor';

    if (isMerchantOfThisOrder || isAdminOrSupervisor) {
      audioAlert.start(`طلب جديد ${orderNum}`);
      setIsSirenRinging(true);
      setActiveAlertOrder(newOrder);
    }

    // Clear cart
    clearCart();

    return newOrder;
  };

  const stopSiren = () => {
    audioAlert.stop();
    setIsSirenRinging(false);
    setActiveAlertOrder(null);
  };

  const testSiren = () => {
    audioAlert.testSound();
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev =>
      prev.map(o => {
        if (o.id === orderId) {
          const updated = { ...o, status, updatedAt: new Date().toISOString() };
          if (status === 'delivered') {
            updated.paymentStatus = 'paid';
          }
          return updated;
        }
        return o;
      })
    );

    // "لما يضغط التاجر على جاري التجهيز يوقف الصوت"
    if (status === 'preparing') {
      stopSiren();
    }
  };

  const assignDriverToOrder = (orderId: string, driverName: string, driverPhone: string): string => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return '';

    const cleanDriverPhone = driverPhone.trim();
    const cleanDriverName = driverName.trim();

    setOrders(prev =>
      prev.map(o =>
        o.id === orderId
          ? {
              ...o,
              driverName: cleanDriverName,
              driverPhone: cleanDriverPhone,
              status: 'out_for_delivery',
              updatedAt: new Date().toISOString()
            }
          : o
      )
    );

    // Generate WhatsApp notification text & link for customer
    const msg = settings.whatsappTemplates.driverAssigned
      .replace('{customer_name}', order.customerName)
      .replace('{order_number}', order.orderNumber)
      .replace('{driver_name}', cleanDriverName)
      .replace('{driver_phone}', cleanDriverPhone);

    const formattedCustPhone = order.customerPhone.startsWith('0')
      ? '2' + order.customerPhone
      : order.customerPhone;
    const whatsappLink = `https://wa.me/${formattedCustPhone.replace(/\+/g, '')}?text=${encodeURIComponent(msg)}`;
    return whatsappLink;
  };

  const cancelOrder = (orderId: string, reason?: string) => {
    setOrders(prev =>
      prev.map(o => (o.id === orderId ? { ...o, status: 'cancelled', notes: `${o.notes || ''} [سبب الإلغاء: ${reason || 'غير محدد'}]` } : o))
    );
    stopSiren();
  };

  // Products CRUD
  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>): Product => {
    const newProduct: Product = {
      ...product,
      id: `prod_${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setProducts(prev => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = (id: string, updatedFields: Partial<Product>) => {
    setProducts(prev => prev.map(p => (p.id === id ? { ...p, ...updatedFields } : p)));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const toggleHideProduct = (id: string) => {
    setProducts(prev => prev.map(p => (p.id === id ? { ...p, isHidden: !p.isHidden } : p)));
  };

  // Trader Management & Ban
  const banTrader = (traderId: string, reason: string, resolutionSteps: string): string => {
    const trader = users.find(u => u.id === traderId);
    if (!trader) return '';

    const now = new Date().toISOString();

    // 1. Mark trader as banned
    setUsers(prev =>
      prev.map(u =>
        u.id === traderId
          ? {
              ...u,
              isBanned: true,
              banReason: reason,
              banDate: now
            }
          : u
      )
    );

    // 2. Automatically hide all products of this trader
    setProducts(prev =>
      prev.map(p => (p.traderId === traderId ? { ...p, isHidden: true } : p))
    );

    // 3. Build automated WhatsApp ban notification message
    const msg = settings.whatsappTemplates.banTrader
      .replace('{trader_name}', trader.name)
      .replace('{reason}', reason)
      .replace('{resolution_steps}', resolutionSteps);

    const formattedTraderPhone = trader.phone.startsWith('0') ? '2' + trader.phone : trader.phone;
    const whatsappUrl = `https://wa.me/${formattedTraderPhone.replace(/\+/g, '')}?text=${encodeURIComponent(msg)}`;
    return whatsappUrl;
  };

  const unbanTrader = (traderId: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === traderId ? { ...u, isBanned: false, banReason: undefined, banDate: undefined } : u))
    );

    // Unhide products
    setProducts(prev =>
      prev.map(p => (p.traderId === traderId ? { ...p, isHidden: false } : p))
    );
  };

  const zeroTraderDebt = (traderId: string, notes?: string) => {
    const trader = users.find(u => u.id === traderId);
    if (!trader) return;

    const currentDebt = trader.debt || 0;

    // Zero out debt
    setUsers(prev =>
      prev.map(u => (u.id === traderId ? { ...u, debt: 0 } : u))
    );

    // Record debt settlement in transactions
    const settlementTx: FinancialTransaction = {
      id: `tx_${Date.now()}_settle`,
      transactionNumber: `TX-SETTLE-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: traderId,
      userName: trader.name,
      userRole: 'trader',
      type: 'debt_settlement',
      amount: currentDebt,
      paymentMethod: 'system_adjustment',
      status: 'completed',
      description: `تصفير المديونية بعد التحقق الفعلي من السداد (${notes || 'سداد معتمد من الإدارة'})`,
      date: new Date().toISOString()
    };

    setTransactions(prev => [settlementTx, ...prev]);
  };

  // Customers
  const banCustomer = (customerId: string, reason?: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === customerId ? { ...u, isBanned: true, banReason: reason || 'حظر من الإدارة' } : u))
    );
  };

  const unbanCustomer = (customerId: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === customerId ? { ...u, isBanned: false, banReason: undefined } : u))
    );
  };

  const deleteUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
  };

  const addOrUpdateUser = (userData: Partial<User>): User => {
    if (userData.id && users.some(u => u.id === userData.id)) {
      setUsers(prev => prev.map(u => (u.id === userData.id ? { ...u, ...userData } as User : u)));
      return users.find(u => u.id === userData.id)!;
    } else {
      const newUser: User = {
        id: `usr_${Date.now()}`,
        name: userData.name || '',
        phone: userData.phone || '',
        email: userData.email || '',
        password: userData.password || '123456',
        role: userData.role || 'customer',
        address: userData.address,
        storeName: userData.storeName,
        supervisorTitle: userData.supervisorTitle,
        supervisorPermissions: userData.supervisorPermissions,
        debt: 0,
        totalSales: 0,
        balance: 0,
        createdAt: new Date().toISOString()
      };
      setUsers(prev => [...prev, newUser]);
      return newUser;
    }
  };

  // Ads
  const addAd = (ad: Omit<Ad, 'id'>): Ad => {
    const newAd: Ad = {
      ...ad,
      id: `ad_${Date.now()}`
    };
    setAds(prev => [newAd, ...prev]);
    return newAd;
  };

  const updateAd = (id: string, adData: Partial<Ad>) => {
    setAds(prev => prev.map(a => (a.id === id ? { ...a, ...adData } : a)));
  };

  const deleteAd = (id: string) => {
    setAds(prev => prev.filter(a => a.id !== id));
  };

  // Settings
  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    setSettings(prev => ({
      ...prev,
      ...newSettings,
      whatsappTemplates: {
        ...prev.whatsappTemplates,
        ...(newSettings.whatsappTemplates || {})
      }
    }));
  };

  return (
    <StoreContext.Provider
      value={{
        currentUser,
        users,
        products,
        orders,
        transactions,
        ads,
        settings,
        resetRequests,
        cart,
        isSirenRinging,
        activeAlertOrder,

        login,
        register,
        logout,
        requestPasswordReset,
        resolvePasswordReset,

        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        getCartTotal,

        createOrder,
        updateOrderStatus,
        assignDriverToOrder,
        cancelOrder,

        addProduct,
        updateProduct,
        deleteProduct,
        toggleHideProduct,

        banTrader,
        unbanTrader,
        zeroTraderDebt,

        banCustomer,
        unbanCustomer,
        deleteUser,
        addOrUpdateUser,

        addAd,
        updateAd,
        deleteAd,

        updateSettings,

        stopSiren,
        testSiren
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
