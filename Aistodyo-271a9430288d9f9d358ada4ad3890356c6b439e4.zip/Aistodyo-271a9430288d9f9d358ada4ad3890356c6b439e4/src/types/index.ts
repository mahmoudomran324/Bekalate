export type UserRole = 'admin' | 'supervisor' | 'trader' | 'customer' | 'captain';

export interface SupervisorPermissions {
  canManageOrders: boolean;
  canManageProducts: boolean;
  canManageTraders: boolean;
  canManageCustomers: boolean;
  canManageDebts: boolean;
  canManageAds: boolean;
  canHandleResets: boolean;
  canViewReports: boolean;
}

export interface Address {
  governorate: string; // المحافظة
  cityOrDistrict: string; // الحي / المركز
  street: string; // الشارع
  building: string; // رقم العمارة / الدور / الشقة
  landmark?: string; // علامة مميزة
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  password?: string;
  role: UserRole;
  address?: Address;
  storeName?: string; // For traders (اسم المحل / المزرعة)
  isBanned?: boolean;
  banReason?: string;
  banDate?: string;
  isApproved?: boolean; // For captains or traders
  debt?: number; // المديونية المستحقة على التاجر
  totalSales?: number; // مبيعات التاجر
  balance?: number; // رصيد
  supervisorPermissions?: SupervisorPermissions;
  supervisorTitle?: string; // تخصص المشرف (مشرف مالي، مشرف جودة، إلخ)
  vehicleType?: string; // For captain (موتوسيكل، تروسيكل، سيارة، عجلة)
  createdAt: string;
}

export type ProductCategory = 'vegetables' | 'fruits' | 'legumes_cheese' | 'dried_goods';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number; // السعر بالجنيه
  unit: string; // كجم، طبق، حبة، ربطة، عبوة، لتر
  stock: number;
  image: string; // Direct image URL or base64 data
  traderId: string;
  traderName: string;
  isHidden: boolean; // مخفي يدوياً أو بسبب حظر التاجر
  description: string;
  discountPrice?: number;
  isOrganic?: boolean;
  freshnessBadge?: string; // قطفة اليوم، بلدي 100%، فرز أول
  createdAt: string;
}

export type OrderStatus = 'new' | 'preparing' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cash' | 'instapay' | 'vodafone_cash' | 'card';
export type PaymentStatus = 'paid' | 'pending' | 'refunded';

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  unit: string;
  traderId: string;
  traderName: string;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. BLD-89412
  customerId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: Address;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  status: OrderStatus;
  notes?: string;
  driverName?: string; // اسم المندوب
  driverPhone?: string; // رقم هاتف المندوب
  createdAt: string;
  updatedAt: string;
  traderIds: string[];
}

export interface FinancialTransaction {
  id: string;
  transactionNumber: string; // e.g. TX-48192
  userId: string;
  userName: string;
  userRole: UserRole;
  type: 'order_payment' | 'commission_deduction' | 'debt_settlement' | 'refund';
  amount: number;
  paymentMethod: PaymentMethod | 'system_adjustment';
  orderId?: string;
  orderNumber?: string;
  status: 'completed' | 'pending' | 'cancelled';
  description: string;
  date: string;
}

export interface Ad {
  id: string;
  title: string;
  description: string;
  image: string; // Uploaded image data
  badgeText?: string;
  targetCategory?: ProductCategory | 'all';
  startDate: string;
  endDate: string;
  isActive: boolean;
  linkText?: string;
}

export interface PasswordResetRequest {
  id: string;
  phone: string;
  userName?: string;
  userEmail?: string;
  userRole?: UserRole;
  requestedAt: string;
  status: 'pending' | 'resolved';
  resolvedAt?: string;
  resolvedBy?: string;
}

export interface StoreSettings {
  storeName: string;
  storeSubtitle: string;
  storeLogo: string;
  instapayAccount: string; // حساب إنستاباي
  vodafoneCashNumber: string; // رقم محفظة فودافون كاش
  deliveryFee: number; // رسوم التوصيل
  platformCommissionRate: number; // نسبة العمولة %
  isCaptainSystemEnabled: boolean; // إظهار أو إخفاء واجهة الكابتن
  supportWhatsApp: string; // رقم الدعم الفني
  termsContent: string;
  qualityCharter: string;
  whatsappTemplates: {
    banTrader: string;
    driverAssigned: string;
    orderReturned: string;
    passwordReset: string;
  };
}
