import { User, Product, StoreSettings, Ad, Order, FinancialTransaction } from '../types';

export const INITIAL_ADMIN: User = {
  id: 'usr_admin_1',
  name: 'محمود عمران (الإدارة العامة)',
  phone: '01099887766',
  email: 'mahmoudomran324@gmail.com',
  password: 'Aa&9119045',
  role: 'admin',
  address: {
    governorate: 'القاهرة',
    cityOrDistrict: 'المعادي',
    street: 'شارع النصر',
    building: 'عمارة 14 - الدور 4',
    landmark: 'بجوار محطة المترو'
  },
  createdAt: '2026-01-01T10:00:00.000Z'
};

export const INITIAL_USERS: User[] = [
  INITIAL_ADMIN,
  {
    id: 'usr_sup_1',
    name: 'أحمد الفقي',
    phone: '01011223344',
    email: 'supervisor@baladi.store',
    password: 'Password123',
    role: 'supervisor',
    supervisorTitle: 'مشرف جودة ورقابة المنتجات والطلبات',
    supervisorPermissions: {
      canManageOrders: true,
      canManageProducts: true,
      canManageTraders: true,
      canManageCustomers: true,
      canManageDebts: true,
      canManageAds: true,
      canHandleResets: true,
      canViewReports: true
    },
    address: {
      governorate: 'الجيزة',
      cityOrDistrict: 'الدقي',
      street: 'شارع التحرير',
      building: 'برج الأطباء',
      landmark: 'ميدان المساحة'
    },
    createdAt: '2026-01-05T12:00:00.000Z'
  },
  {
    id: 'usr_trader_1',
    name: 'الحاج عبد الرحيم النجار',
    phone: '01122334455',
    email: 'abdelrahim@baladi.store',
    password: 'Password123',
    role: 'trader',
    storeName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    debt: 145,
    totalSales: 3850,
    isApproved: true,
    address: {
      governorate: 'الجيزة',
      cityOrDistrict: 'أوسيم',
      street: 'طريق القناطر الزراعي',
      building: 'مزرعة الخير رقم 4',
      landmark: 'أمام محطة المياه'
    },
    createdAt: '2026-01-10T08:00:00.000Z'
  },
  {
    id: 'usr_trader_2',
    name: 'المعلم صبحي الفاكهاني',
    phone: '01233445566',
    email: 'sobhy@baladi.store',
    password: 'Password123',
    role: 'trader',
    storeName: 'واحة الفواكه الطازجة - المعلم صبحي',
    debt: 80,
    totalSales: 2100,
    isApproved: true,
    address: {
      governorate: 'القاهرة',
      cityOrDistrict: 'شبرا',
      street: 'شارع روض الفرج',
      building: 'محل 5',
      landmark: 'بجوار سوق الفاكهة المركزي'
    },
    createdAt: '2026-01-15T09:30:00.000Z'
  },
  {
    id: 'usr_trader_3',
    name: 'الشيخ إبراهيم البركة',
    phone: '01044556677',
    email: 'baraka@baladi.store',
    password: 'Password123',
    role: 'trader',
    storeName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    debt: 210,
    totalSales: 5400,
    isApproved: true,
    address: {
      governorate: 'القاهرة',
      cityOrDistrict: 'مصر القديمة',
      street: 'سوق السلاح التراثي',
      building: 'مبنى البركة',
      landmark: 'أمام وكالة التوابل'
    },
    createdAt: '2026-01-18T11:00:00.000Z'
  },
  {
    id: 'usr_cust_1',
    name: 'مروان الشافعي',
    phone: '01055667788',
    email: 'customer@baladi.store',
    password: 'Password123',
    role: 'customer',
    address: {
      governorate: 'القاهرة',
      cityOrDistrict: 'مدينة نصر',
      street: 'شارع عباس العقاد',
      building: 'عمارة 85 - الدور الثالث - شقة 7',
      landmark: 'خلف بنك مصر'
    },
    createdAt: '2026-02-01T14:20:00.000Z'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // 1. منتجات مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة (usr_trader_1)
  {
    id: 'prod_veg_tomatoes',
    name: 'طماطم بلدي سلك فرز أول (قطفة الصباح)',
    category: 'vegetables',
    price: 18,
    unit: 'كجم',
    stock: 120,
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_1',
    traderName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    isHidden: false,
    description: 'طماطم بلدي طازجة مقطوفة صباح اليوم، حمراء وصلبة مثالية للسلطة والطهي اليومي.',
    freshnessBadge: 'قطفة الصباح',
    isOrganic: true,
    createdAt: '2026-02-01T08:00:00.000Z'
  },
  {
    id: 'prod_veg_potatoes',
    name: 'بطاطس تحمير سبونتا بلدي نخب ممتاز',
    category: 'vegetables',
    price: 25,
    unit: 'كجم',
    stock: 200,
    image: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_1',
    traderName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    isHidden: false,
    description: 'بطاطس سبونتا صحراوي رملية صفراء مقرمشة في التحمير ولا تشرب الزيت.',
    freshnessBadge: 'فرز أول',
    createdAt: '2026-02-01T08:10:00.000Z'
  },
  {
    id: 'prod_veg_cucumbers',
    name: 'خيار بلدي مقرمش صوبة زراعية نخب فاخر',
    category: 'vegetables',
    price: 22,
    discountPrice: 17,
    unit: 'كجم',
    stock: 80,
    image: 'https://images.unsplash.com/photo-1604977042946-1eecc30f269e?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_1',
    traderName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    isHidden: false,
    description: 'خيار بلدي طازج صغير ومقرمش، محصود يومياً بنكهة فلاحي مميزة.',
    freshnessBadge: 'عرض خاص بالاتفاق',
    createdAt: '2026-02-01T08:20:00.000Z'
  },
  {
    id: 'prod_veg_onions',
    name: 'بصل أحمر مصري جيزة خزين فاخر',
    category: 'vegetables',
    price: 24,
    unit: 'كجم',
    stock: 150,
    image: 'https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_1',
    traderName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    isHidden: false,
    description: 'بصل أحمر حبة ناشفة ونظيفة، ممتاز للتخزين والطبخ اليومي بنكهة قوية.',
    freshnessBadge: 'فرز أول',
    createdAt: '2026-02-01T08:30:00.000Z'
  },
  {
    id: 'prod_veg_molokhia',
    name: 'ملوخية فلاحي طازجة بالعرق قطفة الصباح',
    category: 'vegetables',
    price: 15,
    unit: 'ربطة نصف كيلو',
    stock: 60,
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_1',
    traderName: 'مزارع الحاج عبد الرحيم للخضار والفاكهة الطازجة',
    isHidden: false,
    description: 'ملوخية بلدي فلاحي خضراء ومورقة، ذات عرق كثيف ونكهة مصرية أصيلة.',
    freshnessBadge: 'قطفة الصباح',
    isOrganic: true,
    createdAt: '2026-02-01T08:40:00.000Z'
  },

  // 2. منتجات واحة الفواكه الطازجة - المعلم صبحي (usr_trader_2)
  {
    id: 'prod_frt_oranges',
    name: 'برتقال بلدي عصير قطفة اليوم طازج',
    category: 'fruits',
    price: 16,
    unit: 'كجم',
    stock: 100,
    image: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_2',
    traderName: 'واحة الفواكه الطازجة - المعلم صبحي',
    isHidden: false,
    description: 'برتقال بلدي مصري غني بالعصير النقي وفيتامين سي، مثالي للعصائر الطبيعية.',
    freshnessBadge: 'بلدي 100%',
    createdAt: '2026-02-01T09:00:00.000Z'
  },
  {
    id: 'prod_frt_bananas',
    name: 'موز بلدي سكري طازج نخب أول',
    category: 'fruits',
    price: 25,
    unit: 'كجم',
    stock: 90,
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_2',
    traderName: 'واحة الفواكه الطازجة - المعلم صبحي',
    isHidden: false,
    description: 'موز بلدي ناضج طبيعياً بحلاوة معتدلة وطعم بلدي فريد.',
    freshnessBadge: 'طازج اليوم',
    createdAt: '2026-02-01T09:10:00.000Z'
  },
  {
    id: 'prod_frt_apples',
    name: 'تفاح أحمر سكري فاخر نخب أول',
    category: 'fruits',
    price: 65,
    discountPrice: 54,
    unit: 'كجم',
    stock: 75,
    image: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_2',
    traderName: 'واحة الفواكه الطازجة - المعلم صبحي',
    isHidden: false,
    description: 'تفاح أحمر مقرمش وسكري عالي الجودة بنكهة لذيذة ورائحة منعشة.',
    freshnessBadge: 'عرض خاص بالاتفاق',
    createdAt: '2026-02-01T09:20:00.000Z'
  },
  {
    id: 'prod_frt_strawberries',
    name: 'فراولة بلدي إسماعيلية نخب ممتاز',
    category: 'fruits',
    price: 38,
    discountPrice: 30,
    unit: 'طبق 1 كجم',
    stock: 50,
    image: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_2',
    traderName: 'واحة الفواكه الطازجة - المعلم صبحي',
    isHidden: false,
    description: 'فراولة إسماعيلية حمراء ومعسلة، منتقاة حبة بحبة ومغسولة بعناية.',
    freshnessBadge: 'تخفيض موسمي',
    createdAt: '2026-02-01T09:30:00.000Z'
  },
  {
    id: 'prod_frt_guava',
    name: 'جوافة بلدي بناتي معسلة نخب فاخر',
    category: 'fruits',
    price: 32,
    unit: 'كجم',
    stock: 65,
    image: 'https://images.unsplash.com/photo-1536511132770-e5058c7e8c46?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_2',
    traderName: 'واحة الفواكه الطازجة - المعلم صبحي',
    isHidden: false,
    description: 'جوافة بلدي بيضاء برائحة نفاذة وطعم سكري وقوام متماسك.',
    freshnessBadge: 'بلدي 100%',
    createdAt: '2026-02-01T09:40:00.000Z'
  },

  // 3. منتجات عطارة ومجففات وبقوليات البركة الأصلية (usr_trader_3)
  {
    id: 'prod_leg_foul',
    name: 'فول تدميس بلدي مصري حبة عريضة منقى',
    category: 'legumes_cheese',
    price: 55,
    unit: 'كجم',
    stock: 100,
    image: 'https://images.unsplash.com/photo-1551462147-ff29053bfc14?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'فول بلدي مصري نخب أول حبة كبيرة وقشرة رقيقة، ينضج كالزبدة عند التدميس.',
    freshnessBadge: 'نخب أول',
    createdAt: '2026-02-01T10:00:00.000Z'
  },
  {
    id: 'prod_leg_lentils',
    name: 'عدس أصفر مصري منقى نخب فاخر',
    category: 'legumes_cheese',
    price: 65,
    unit: 'كجم',
    stock: 80,
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'عدس أصفر نقي وسريع النضج لشوربة العدس والفتة المصرية الأصيلة.',
    freshnessBadge: 'منقى آلياً',
    createdAt: '2026-02-01T10:10:00.000Z'
  },
  {
    id: 'prod_leg_cheese',
    name: 'جبنة بيضاء براميلي بلدي فلاحي معتقة',
    category: 'legumes_cheese',
    price: 180,
    discountPrice: 160,
    unit: 'كجم',
    stock: 45,
    image: 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'جبنة براميلي فلاحي طبيعية 100% مصنوعة من لبن جاموسي صافي معتقة بالفلفل الأخضر.',
    freshnessBadge: 'عرض خاص بالاتفاق',
    createdAt: '2026-02-01T10:20:00.000Z'
  },
  {
    id: 'prod_drd_figs',
    name: 'تين مجفف طبيعي بلدي نخب فاخر',
    category: 'dried_goods',
    price: 160,
    unit: 'عبوة 500 جم',
    stock: 40,
    image: 'https://images.unsplash.com/photo-1596547609652-9cf5d8d76921?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'تين مجفف شمسياً بدون مواد حافظة أو سكريات مضافة، طري وغني بالحلاوة الطبيعية.',
    freshnessBadge: 'طبيعي 100%',
    isOrganic: true,
    createdAt: '2026-02-01T10:30:00.000Z'
  },
  {
    id: 'prod_drd_karkadeh',
    name: 'كركديه أسواني زهرة كاملة لوزة فاخرة',
    category: 'dried_goods',
    price: 110,
    discountPrice: 95,
    unit: 'عبوة 500 جم',
    stock: 65,
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'كركديه أسواني طبيعي زهرة كاملة بدون شوائب، يمنح لوناً ياقوتياً وطعماً منعشاً.',
    freshnessBadge: 'عرض خاص بالاتفاق',
    createdAt: '2026-02-01T10:40:00.000Z'
  },
  {
    id: 'prod_drd_cumin',
    name: 'كمون بلدي حب ومطحون على الحجر نقي 100%',
    category: 'dried_goods',
    price: 45,
    unit: 'عبوة 150 جم',
    stock: 90,
    image: 'https://images.unsplash.com/photo-1599940824399-b87987ceb72a?w=600&auto=format&fit=crop&q=80',
    traderId: 'usr_trader_3',
    traderName: 'عطارة ومجففات وبقوليات البركة الأصلية',
    isHidden: false,
    description: 'كمون بلدي محمص ومطحون طازج بدون أي إضافات، نفاذ الرائحة للمطبخ المصري.',
    freshnessBadge: 'عطارة أصلية',
    createdAt: '2026-02-01T10:50:00.000Z'
  }
];

export const INITIAL_ADS: Ad[] = [
  {
    id: 'ad_1',
    title: 'عرض مهرجان الطماطم والخضار البلدي',
    description: 'منتجات طازجة من المزارع مباشرة لبيتك وبأعلى معايير النظافة والجودة المضمونة!',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=1200&auto=format&fit=crop&q=80',
    badgeText: 'طازج 100%',
    targetCategory: 'vegetables',
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    isActive: true,
    linkText: 'تسوق الخضار الآن'
  }
];

export const INITIAL_SETTINGS: StoreSettings = {
  storeName: 'متجر بلدي - أحلى بقالة',
  storeSubtitle: 'للخضار والفاكهة والبقوليات والجبن والمجففات من خير مزارعنا',
  storeLogo: '', // Can be loaded or updated
  instapayAccount: 'baladi@instapay',
  vodafoneCashNumber: '01099887766',
  deliveryFee: 20,
  platformCommissionRate: 5,
  isCaptainSystemEnabled: false, // Hidden by default as requested
  supportWhatsApp: '+201099887766',
  termsContent: `ميثاق الجودة وسياسة الاسترجاع في منصة متجر بلدي:
1. الجودة خط أحمر: نتعهد بتوفير خضار وفاكهة ومنتجات فرز أول طازجة بالكامل.
2. التحذير الصارم من البضاعة التالفة: يمنع منعاً باتاً عرض أو شحن أي منتجات غير مطابقة للجودة أو تالفة.
3. الاسترجاع الفوري المجاني: في حال وصول أي صنف غير مطابق أو غير طازج، يحق للعميل استرجاعه فوراً واسترداد قيمته كاملة بدون أي رسوم شحن إضافية.
4. مسؤولية التاجر: يتحمل التاجر المسؤولية الكاملة وتكلفة الاسترجاع عند إرسال أي بضاعة تالفة مع تعرض حسابه للحظر الفوري.`,
  qualityCharter: `نحن في "متجر بلدي" نضمن لك سلامة ونظافة المحصول من شجرة الفلاح وحتى باب منزلك مع ضمان استرداد فوري للأموال.`,
  whatsappTemplates: {
    banTrader: `السلام عليكم أخي التاجر {trader_name}،
تم إيقاف متجرك مؤقتاً على منصة متجر بلدي للسبب الآتي:
{reason}
الخطوات المطلوبة لحل المشكلة وتفعيل الحساب:
{resolution_steps}
يرجى التواصل معنا لتسوية الوضع فوراً. إدارة متجر بلدي.`,
    driverAssigned: `مرحباً بك عميلنا العزيز {customer_name}!
طلبك رقم #{order_number} جاري توصيله الآن 🛵
المندوب اتحرك، اسمه: {driver_name}
وتليفونه للتواصل المباشر: {driver_phone}
شكراً لثقتك في متجر بلدي!`,
    orderReturned: `إشعار استرجاع بضاعة:
بخصوص الطلب #{order_number} للتاجر {trader_name}.
تم تسجيل استرجاع منتجات تالفة وتم قيد المبلغ كاملاً في حساب العميل وتحميل القيمة على حساب التاجر وفق ميثاق الجودة.`,
    passwordReset: `السلام عليكم {user_name}،
بناءً على طلبك لاستعادة كلمة المرور في متجر بلدي، بيانات دخولك هي:
البريد الإلكتروني: {email}
كلمة المرور المؤقتة: {password}
رابط الدخول: {store_url}`
  }
};

export const INITIAL_ORDERS: Order[] = [];

export const INITIAL_TRANSACTIONS: FinancialTransaction[] = [];
