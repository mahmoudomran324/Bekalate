/**
 * Web Audio API synthesizer for the Merchant alert siren/chime.
 * Plays a loud, distinctive repeating alert when a new order arrives
 * and stops immediately when the merchant clicks "جاري التجهيز".
 */

class AudioAlertManager {
  private audioCtx: AudioContext | null = null;
  private isAlerting: boolean = false;
  private intervalId: any = null;

  private initContext() {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /**
   * Synthesizes a loud, high-impact two-tone chime beep
   */
  private playBeep(freq1 = 880, freq2 = 1174.66, duration = 0.35) {
    try {
      this.initContext();
      if (!this.audioCtx) return;

      const now = this.audioCtx.currentTime;

      // Primary oscillator (Tone 1)
      const osc1 = this.audioCtx.createOscillator();
      const gain1 = this.audioCtx.createGain();

      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(freq1, now);
      osc1.frequency.exponentialRampToValueAtTime(freq2, now + duration * 0.5);

      gain1.gain.setValueAtTime(0.001, now);
      gain1.gain.linearRampToValueAtTime(0.9, now + 0.04);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc1.connect(gain1);
      gain1.connect(this.audioCtx.destination);

      osc1.start(now);
      osc1.stop(now + duration);

      // Harmonics oscillator (Tone 2 for loudness & high presence)
      const osc2 = this.audioCtx.createOscillator();
      const gain2 = this.audioCtx.createGain();

      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(freq2 * 1.5, now);
      osc2.frequency.exponentialRampToValueAtTime(freq1 * 1.5, now + duration * 0.8);

      gain2.gain.setValueAtTime(0.001, now);
      gain2.gain.linearRampToValueAtTime(0.4, now + 0.05);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc2.connect(gain2);
      gain2.connect(this.audioCtx.destination);

      osc2.start(now);
      osc2.stop(now + duration);
    } catch (e) {
      console.warn('Audio alert sound synthesis error:', e);
    }
  }

  /**
   * Start loud repeating siren
   */
  public start(label?: string) {
    if (this.isAlerting) return;
    this.isAlerting = true;
    this.initContext();

    // Play immediately
    this.playBeep(880, 1318.51, 0.4);
    setTimeout(() => {
      if (this.isAlerting) this.playBeep(1046.5, 1567.98, 0.4);
    }, 250);

    // Repeat every 1.5 seconds until stopped
    this.intervalId = setInterval(() => {
      if (!this.isAlerting) {
        clearInterval(this.intervalId);
        return;
      }
      this.playBeep(880, 1318.51, 0.35);
      setTimeout(() => {
        if (this.isAlerting) this.playBeep(1174.66, 1760, 0.35);
      }, 200);
    }, 1400);

    console.log(`[AudioAlert] Alert started: ${label || 'New incoming order'}`);
  }

  /**
   * Stop siren immediately (e.g. when clicking "جاري التجهيز")
   */
  public stop() {
    this.isAlerting = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    console.log('[AudioAlert] Alert stopped by merchant');
  }

  public getIsPlaying(): boolean {
    return this.isAlerting;
  }

  public testSound() {
    this.initContext();
    this.playBeep(987.77, 1318.51, 0.3);
  }
}

export const audioAlert = new AudioAlertManager();
