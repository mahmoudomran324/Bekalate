import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { PaymentMethod, Order } from '../types';
import {
  X,
  CreditCard,
  Banknote,
  Smartphone,
  Copy,
  CheckCircle2,
  AlertCircle,
  Truck,
  MapPin,
  ShieldCheck,
  Check
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  onOrderSuccess
}) => {
  const { currentUser, getCartTotal, createOrder, settings } = useStore();
  const { subtotal, deliveryFee, total } = getCartTotal();

  // Form State
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '');
  const [governorate, setGovernorate] = useState(currentUser?.address?.governorate || 'القاهرة');
  const [cityOrDistrict, setCityOrDistrict] = useState(currentUser?.address?.cityOrDistrict || '');
  const [street, setStreet] = useState(currentUser?.address?.street || '');
  const [building, setBuilding] = useState(currentUser?.address?.building || '');
  const [landmark, setLandmark] = useState(currentUser?.address?.landmark || '');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [copiedInstapay, setCopiedInstapay] = useState(false);
  const [copiedVodafone, setCopiedVodafone] = useState(false);

  if (!isOpen) return null;

  const handleCopyText = (text: string, type: 'instapay' | 'vodafone') => {
    navigator.clipboard.writeText(text);
    if (type === 'instapay') {
      setCopiedInstapay(true);
      setTimeout(() => setCopiedInstapay(false), 2000);
    } else {
      setCopiedVodafone(true);
      setTimeout(() => setCopiedVodafone(false), 2000);
    }
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim() || !customerPhone.trim() || !cityOrDistrict.trim() || !street.trim()) {
      setError('يرجى ملء جميع بيانات التوصيل الأساسية (الاسم، الهاتف، الحي، والشارع)');
      return;
    }

    try {
      const newOrder = createOrder({
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: {
          governorate: governorate.trim(),
          cityOrDistrict: cityOrDistrict.trim(),
          street: street.trim(),
          building: building.trim(),
          landmark: landmark.trim()
        },
        paymentMethod,
        notes: notes.trim()
      });

      onOrderSuccess(newOrder);
      onClose();
    } catch (err: any) {
      setError('حدث خطأ أثناء حفظ الطلب، يرجى المحاولة ثانية');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-emerald-100 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-green-800 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Truck className="w-6 h-6 text-amber-300" />
            <div>
              <h2 className="text-xl font-black">إتمام وتأكيد طلب الشراء</h2>
              <p className="text-emerald-100 text-xs">
                بيانات التوصيل واختيار وسيلة السداد الآمنة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Form */}
        <form onSubmit={handlePlaceOrder} className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: Customer Contact */}
          <div>
            <h3 className="text-sm font-extrabold text-stone-800 mb-2 flex items-center gap-1.5">
              <span>بيانات المستلم والتواصل</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-stone-600 mb-1 font-semibold">
                  اسم المستلم بالكامل
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  placeholder="محمد أحمد..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1 font-semibold">
                  رقم الهاتف للتواصل وتتبع المندوب
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={e => setCustomerPhone(e.target.value)}
                  placeholder="01012345678"
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>
            </div>
          </div>

          {/* Section 2: Detailed Delivery Address */}
          <div className="pt-3 border-t border-stone-100">
            <h3 className="text-sm font-extrabold text-stone-800 mb-2 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-700" />
              <span>عنوان التوصيل بالتفصيل</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2">
              <div>
                <label className="block text-xs text-stone-600 mb-1 font-semibold">المحافظة</label>
                <input
                  type="text"
                  value={governorate}
                  onChange={e => setGovernorate(e.target.value)}
                  placeholder="القاهرة / الجيزة..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1 font-semibold">
                  المدينة / الحي / المركز
                </label>
                <input
                  type="text"
                  value={cityOrDistrict}
                  onChange={e => setCityOrDistrict(e.target.value)}
                  placeholder="المعادي / المهندسين / الدقي..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-2">
              <div className="sm:col-span-2">
                <label className="block text-xs text-stone-600 mb-1 font-semibold">اسم الشارع</label>
                <input
                  type="text"
                  value={street}
                  onChange={e => setStreet(e.target.value)}
                  placeholder="شارع الجمهورية الرئيسي..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                  required
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1 font-semibold">
                  رقم العمارة / الدور / الشقة
                </label>
                <input
                  type="text"
                  value={building}
                  onChange={e => setBuilding(e.target.value)}
                  placeholder="عمارة 12 شقة 3"
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-stone-600 mb-1 font-semibold">
                علامة مميزة (اختياري)
              </label>
              <input
                type="text"
                value={landmark}
                onChange={e => setLandmark(e.target.value)}
                placeholder="بجوار سوبرماركت... / خلف البنك..."
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
              />
            </div>
          </div>

          {/* Section 3: Payment Method */}
          <div className="pt-3 border-t border-stone-100">
            <h3 className="text-sm font-extrabold text-stone-800 mb-2 flex items-center justify-between">
              <span>طريقة الدفع المختارة</span>
              <span className="text-[11px] text-emerald-700 font-bold">
                تسجيل المعاملة رسميًا بقاعدة البيانات
              </span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {/* Option 1: Cash */}
              <button
                type="button"
                onClick={() => setPaymentMethod('cash')}
                className={`p-3 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
                  paymentMethod === 'cash'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/30'
                    : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                }`}
              >
                <Banknote className="w-5 h-5 text-emerald-600 mb-2" />
                <span className="font-bold text-xs">كاش عند الاستلام</span>
              </button>

              {/* Option 2: InstaPay */}
              <button
                type="button"
                onClick={() => setPaymentMethod('instapay')}
                className={`p-3 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
                  paymentMethod === 'instapay'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/30'
                    : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                }`}
              >
                <Smartphone className="w-5 h-5 text-purple-600 mb-2" />
                <span className="font-bold text-xs">إنستاباي InstaPay</span>
              </button>

              {/* Option 3: Vodafone Cash */}
              <button
                type="button"
                onClick={() => setPaymentMethod('vodafone_cash')}
                className={`p-3 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
                  paymentMethod === 'vodafone_cash'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/30'
                    : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                }`}
              >
                <Smartphone className="w-5 h-5 text-red-600 mb-2" />
                <span className="font-bold text-xs">فودافون كاش</span>
              </button>

              {/* Option 4: Card */}
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-3 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
                  paymentMethod === 'card'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/30'
                    : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                }`}
              >
                <CreditCard className="w-5 h-5 text-blue-600 mb-2" />
                <span className="font-bold text-xs">فيزا / ماستركارد</span>
              </button>
            </div>

            {/* Dynamic details for InstaPay */}
            {paymentMethod === 'instapay' && (
              <div className="mt-3 p-3.5 bg-purple-50 rounded-2xl border border-purple-200 text-xs text-purple-900 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold">حساب إنستاباي المعتمد للمتجر:</span>
                  <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-purple-200">
                    <span className="font-mono font-black text-purple-800">
                      {settings.instapayAccount}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyText(settings.instapayAccount, 'instapay')}
                      className="text-purple-600 hover:text-purple-900"
                      title="نسخ الحساب"
                    >
                      {copiedInstapay ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-purple-700">
                  يرجى تحويل مبلغ ({total} جنيه) على عنوان إنستاباي أعلاه، وسيتم إرفاق إشعار التحويل تلقائياً.
                </p>
              </div>
            )}

            {/* Dynamic details for Vodafone Cash */}
            {paymentMethod === 'vodafone_cash' && (
              <div className="mt-3 p-3.5 bg-red-50 rounded-2xl border border-red-200 text-xs text-red-900 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold">رقم محفظة فودافون كاش للمتجر:</span>
                  <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-lg border border-red-200">
                    <span className="font-mono font-black text-red-700">
                      {settings.vodafoneCashNumber}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopyText(settings.vodafoneCashNumber, 'vodafone')}
                      className="text-red-600 hover:text-red-900"
                      title="نسخ الرقم"
                    >
                      {copiedVodafone ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-red-700">
                  يرجى تحويل مبلغ ({total} جنيه) لمحفظة فودافون كاش أعلاه والاحتفاظ برسالة التأكيد.
                </p>
              </div>
            )}
          </div>

          {/* Section 4: Notes */}
          <div>
            <label className="block text-xs text-stone-600 mb-1 font-semibold">
              ملاحظات إضافية للتاجر أو المندوب (اختياري)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="مثال: يرجى الاتصال عند الوصول، أو اختيار طماطم صلبة..."
              className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
            />
          </div>

          {/* Section 5: Order Breakdown & Confirm */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
            <div className="flex justify-between text-xs text-stone-600">
              <span>إجمالي الأصناف:</span>
              <span className="font-bold text-stone-800">{subtotal} جنيه</span>
            </div>
            <div className="flex justify-between text-xs text-stone-600">
              <span>رسوم التوصيل المباشر:</span>
              <span className="font-bold text-stone-800">{deliveryFee} جنيه</span>
            </div>
            <div className="flex justify-between text-sm md:text-base font-black text-stone-900 pt-2 border-t border-stone-200">
              <span>المجموع النهائي المستحق:</span>
              <span className="text-emerald-700 text-lg">{total} جنيه مصري</span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-2xl shadow-lg transition active:scale-95 cursor-pointer text-sm md:text-base flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5 text-amber-300" />
            <span>تأكيد الطلب وإرسال التنبيه الفوري للتاجر 🔔</span>
          </button>
        </form>
      </div>
    </div>
  );
};
