import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { Product, ProductCategory } from '../types';
import {
  Search,
  SlidersHorizontal,
  Plus,
  Minus,
  Check,
  Store,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  ShoppingBag,
  Info,
  X
} from 'lucide-react';

interface StoreFrontProps {
  onOpenProductDetail?: (product: Product) => void;
}

export const StoreFront: React.FC<StoreFrontProps> = () => {
  const { products, ads, users, addToCart, cart, settings } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'all' | 'offers'>('all');
  const [selectedTraderId, setSelectedTraderId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'name'>('featured');
  const [activeAdIndex, setActiveAdIndex] = useState(0);

  // Selected product modal for quick inspection
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);
  const [quantityMap, setQuantityMap] = useState<{ [productId: string]: number }>({});

  // Active Ads list
  const activeAds = useMemo(() => {
    return ads.filter(ad => ad.isActive);
  }, [ads]);

  // Active Traders list (unbanned traders)
  const activeTraders = useMemo(() => {
    return users.filter(u => u.role === 'trader' && !u.isBanned);
  }, [users]);

  // Filtered products: MUST exclude products marked as hidden or whose trader is banned!
  const filteredProducts = useMemo(() => {
    // Get list of banned trader IDs
    const bannedTraderIds = new Set(
      users.filter(u => u.role === 'trader' && u.isBanned).map(u => u.id)
    );

    return products.filter(product => {
      // 1. Hide if product itself is hidden or trader is banned
      if (product.isHidden || bannedTraderIds.has(product.traderId)) {
        return false;
      }

      // 2. Category filter
      if (selectedCategory === 'offers') {
        if (!product.discountPrice || product.discountPrice >= product.price) {
          return false;
        }
      } else if (selectedCategory !== 'all' && product.category !== selectedCategory) {
        return false;
      }

      // 3. Trader filter
      if (selectedTraderId !== 'all' && product.traderId !== selectedTraderId) {
        return false;
      }

      // 4. Search query
      if (searchQuery.trim()) {
        const query = searchQuery.trim().toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesDesc = product.description?.toLowerCase().includes(query);
        const matchesTrader = product.traderName?.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesTrader) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price_low') {
        return (a.discountPrice || a.price) - (b.discountPrice || b.price);
      }
      if (sortBy === 'price_high') {
        return (b.discountPrice || b.price) - (a.discountPrice || a.price);
      }
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name, 'ar');
      }
      return 0; // default order
    });
  }, [products, users, selectedCategory, selectedTraderId, searchQuery, sortBy]);

  const handleQuantityChange = (productId: string, delta: number) => {
    setQuantityMap(prev => {
      const current = prev[productId] || 1;
      const next = Math.max(1, current + delta);
      return { ...prev, [productId]: next };
    });
  };

  const handleAddToCart = (product: Product) => {
    const qty = quantityMap[product.id] || 1;
    addToCart(product, qty);
    // Flash reset
    setQuantityMap(prev => ({ ...prev, [product.id]: 1 }));
  };

  const getCartQuantityForProduct = (productId: string) => {
    const item = cart.find(c => c.product.id === productId);
    return item ? item.quantity : 0;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-8">
      {/* 1. ADS & PROMOTION BANNER CAROUSEL */}
      {activeAds.length > 0 && (
        <div className="relative rounded-3xl overflow-hidden shadow-xl bg-emerald-950 text-white min-h-[220px] md:min-h-[280px] flex items-center">
          {activeAds.map((ad, idx) => (
            <div
              key={ad.id}
              className={`absolute inset-0 transition-opacity duration-700 flex flex-col md:flex-row items-center justify-between ${
                idx === activeAdIndex ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
              }`}
            >
              {/* Background image overlay */}
              <div className="absolute inset-0 z-0">
                <img
                  src={ad.image}
                  alt={ad.title}
                  className="w-full h-full object-cover opacity-35 filter brightness-75 scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-emerald-950 via-emerald-950/80 to-transparent"></div>
              </div>

              {/* Text content */}
              <div className="relative z-10 p-6 md:p-10 max-w-xl space-y-3">
                {ad.badgeText && (
                  <span className="inline-flex items-center gap-1.5 bg-amber-400 text-stone-900 font-black text-xs px-3 py-1 rounded-full shadow-md">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{ad.badgeText}</span>
                  </span>
                )}
                <h1 className="text-2xl md:text-4xl font-black text-white leading-tight">
                  {ad.title}
                </h1>
                <p className="text-emerald-100 text-xs md:text-sm line-clamp-2 md:line-clamp-3">
                  {ad.description}
                </p>

                {ad.targetCategory && ad.targetCategory !== 'all' && (
                  <button
                    onClick={() => setSelectedCategory(ad.targetCategory as ProductCategory)}
                    className="inline-flex items-center gap-2 bg-white hover:bg-emerald-50 text-emerald-900 font-extrabold text-xs md:text-sm px-5 py-2.5 rounded-xl shadow-lg transition active:scale-95 cursor-pointer"
                  >
                    <span>{ad.linkText || 'تسوق العرض الآن'}</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}

          {/* Carousel controls if more than 1 ad */}
          {activeAds.length > 1 && (
            <div className="absolute bottom-4 left-6 z-20 flex items-center gap-2">
              <button
                onClick={() =>
                  setActiveAdIndex(prev => (prev === 0 ? activeAds.length - 1 : prev - 1))
                }
                className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 text-white transition backdrop-blur-xs"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <div className="flex gap-1.5">
                {activeAds.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveAdIndex(i)}
                    className={`h-2 rounded-full transition-all ${
                      i === activeAdIndex ? 'w-6 bg-amber-400' : 'w-2 bg-white/40'
                    }`}
                  />
                ))}
              </div>
              <button
                onClick={() =>
                  setActiveAdIndex(prev => (prev === activeAds.length - 1 ? 0 : prev + 1))
                }
                className="p-1.5 rounded-full bg-white/20 hover:bg-white/40 text-white transition backdrop-blur-xs"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* 2. CATEGORY SELECTOR CARDS */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl md:text-2xl font-black text-stone-900">
            أقسام المتجر الطازجة
          </h2>
          <span className="text-xs text-stone-500 font-semibold">
            {filteredProducts.length} صنف متاح
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                : 'bg-white hover:bg-emerald-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🌿</span>
            <div>
              <h3 className="font-bold text-sm">كل الأقسام</h3>
              <p className={`text-[11px] ${selectedCategory === 'all' ? 'text-emerald-100' : 'text-stone-400'}`}>
                جميع الأصناف
              </p>
            </div>
          </button>

          <button
            onClick={() => setSelectedCategory('offers')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'offers'
                ? 'bg-amber-500 text-stone-900 border-amber-500 shadow-md ring-2 ring-amber-400/40'
                : 'bg-white hover:bg-amber-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🏷️</span>
            <div>
              <h3 className="font-bold text-sm">عروض وتخفيضات</h3>
              <p className={`text-[11px] ${selectedCategory === 'offers' ? 'text-amber-950 font-semibold' : 'text-stone-400'}`}>
                أسعار مخفضة بالاتفاق
              </p>
            </div>
          </button>

          <button
            onClick={() => setSelectedCategory('vegetables')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'vegetables'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                : 'bg-white hover:bg-emerald-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🥬</span>
            <div>
              <h3 className="font-bold text-sm">خضروات طازجة</h3>
              <p className={`text-[11px] ${selectedCategory === 'vegetables' ? 'text-emerald-100' : 'text-stone-400'}`}>
                قطفة اليوم من الحقل
              </p>
            </div>
          </button>

          <button
            onClick={() => setSelectedCategory('fruits')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'fruits'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                : 'bg-white hover:bg-emerald-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🍎</span>
            <div>
              <h3 className="font-bold text-sm">فواكه موسمية</h3>
              <p className={`text-[11px] ${selectedCategory === 'fruits' ? 'text-emerald-100' : 'text-stone-400'}`}>
                سكري وعصير فرز أول
              </p>
            </div>
          </button>

          <button
            onClick={() => setSelectedCategory('legumes_cheese')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'legumes_cheese'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                : 'bg-white hover:bg-emerald-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🧀</span>
            <div>
              <h3 className="font-bold text-sm">بقوليات وجبن بلدي</h3>
              <p className={`text-[11px] ${selectedCategory === 'legumes_cheese' ? 'text-emerald-100' : 'text-stone-400'}`}>
                قريش، براميلي وفول
              </p>
            </div>
          </button>

          <button
            onClick={() => setSelectedCategory('dried_goods')}
            className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
              selectedCategory === 'dried_goods'
                ? 'bg-emerald-700 text-white border-emerald-700 shadow-md ring-2 ring-emerald-500/30'
                : 'bg-white hover:bg-emerald-50 text-stone-700 border-stone-200'
            }`}
          >
            <span className="text-2xl mb-2">🧄</span>
            <div>
              <h3 className="font-bold text-sm">مجففات وعطارة</h3>
              <p className={`text-[11px] ${selectedCategory === 'dried_goods' ? 'text-emerald-100' : 'text-stone-400'}`}>
                تين، ملوخية ناشفة وتوابل
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* 3. SEARCH & TRADER FILTERS BAR */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-stone-400 absolute right-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="ابحث عن خضار، فاكهة، جبنة، أو تاجر..."
            className="w-full pr-10 pl-4 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-2.5 text-stone-400 hover:text-stone-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Trader Filter Dropdown: "يقدر العميل يختار من أي تاجر" */}
        <div className="flex items-center gap-2">
          <Store className="w-4 h-4 text-emerald-700 shrink-0" />
          <select
            value={selectedTraderId}
            onChange={e => setSelectedTraderId(e.target.value)}
            className="bg-stone-50 border border-stone-200 text-stone-800 text-xs md:text-sm rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="all">كل المزارع والتجار المعتمدين</option>
            {activeTraders.map(t => (
              <option key={t.id} value={t.id}>
                {t.storeName || t.name}
              </option>
            ))}
          </select>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-stone-500 shrink-0" />
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="bg-stone-50 border border-stone-200 text-stone-800 text-xs md:text-sm rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="featured">المميز والأحدث</option>
            <option value="price_low">السعر: من الأقل للأعلى</option>
            <option value="price_high">السعر: من الأعلى للأقل</option>
            <option value="name">أبجديًا</option>
          </select>
        </div>
      </div>

      {/* 4. PRODUCTS GRID VIEW: "عرض منتجات المتجر في شكل شبكه وليس قائمه" */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 md:p-14 text-center border border-stone-200 max-w-xl mx-auto space-y-4 shadow-xs">
          <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto text-3xl">
            🧺
          </div>
          <div>
            <h3 className="text-lg md:text-xl font-black text-stone-800">
              {products.length === 0
                ? 'المتجر نظيف وجاهز بدون أي بيانات وهمية'
                : 'لا توجد منتجات مطابقة لهذا القسم حالياً'}
            </h3>
            <p className="text-xs md:text-sm text-stone-500 max-w-md mx-auto mt-1 leading-relaxed">
              {products.length === 0
                ? 'تم حذف كافة المنتجات الافتراضية بنجاح. تظهر هنا فقط المنتجات الحقيقية التي يقوم التجار أو المشرفون بإضافتها فعلياً للمتجر مع إمكانية عمل عروض وتخفيضات عليها.'
                : 'جرب اختيار قسم آخر أو إلغاء فلتر التاجر لمشاهدة المنتجات الحقيقية المتاحة.'}
            </p>
          </div>
          {products.length > 0 && (
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSelectedTraderId('all');
                setSearchQuery('');
              }}
              className="px-5 py-2.5 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition cursor-pointer shadow-xs"
            >
              عرض كافة المنتجات الحقيقية المتاحة
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
          {filteredProducts.map(product => {
            const currentQty = quantityMap[product.id] || 1;
            const inCartQty = getCartQuantityForProduct(product.id);

            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-xl transition-all flex flex-col group"
              >
                {/* Image & Badges */}
                <div className="relative aspect-square overflow-hidden bg-stone-100 cursor-pointer" onClick={() => setInspectProduct(product)}>
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />

                  {/* Freshness or Deal Badge */}
                  {product.discountPrice && product.discountPrice < product.price ? (
                    <span className="absolute top-2.5 right-2.5 bg-amber-400 text-stone-900 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-md flex items-center gap-1">
                      <span>🏷️</span>
                      <span>{product.freshnessBadge || 'عرض خاص بالاتفاق'}</span>
                    </span>
                  ) : product.freshnessBadge ? (
                    <span className="absolute top-2.5 right-2.5 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-md">
                      {product.freshnessBadge}
                    </span>
                  ) : null}

                  {product.isOrganic && (
                    <span className="absolute top-2.5 left-2.5 bg-amber-400 text-stone-900 text-[10px] font-black px-2 py-0.5 rounded-full shadow-md">
                      بلدي 100%
                    </span>
                  )}

                  {inCartQty > 0 && (
                    <div className="absolute bottom-2 left-2 bg-emerald-900/90 text-white text-[11px] font-bold px-2 py-1 rounded-lg backdrop-blur-xs flex items-center gap-1 shadow">
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>في السلة: {inCartQty}</span>
                    </div>
                  )}
                </div>

                {/* Details */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    {/* Trader Name */}
                    <div className="flex items-center gap-1 text-[11px] text-stone-400 mb-1">
                      <Store className="w-3 h-3 text-emerald-600 shrink-0" />
                      <span className="line-clamp-1">{product.traderName}</span>
                    </div>

                    {/* Product Title */}
                    <h3
                      onClick={() => setInspectProduct(product)}
                      className="font-black text-stone-900 text-sm md:text-base leading-snug line-clamp-2 hover:text-emerald-700 transition cursor-pointer"
                    >
                      {product.name}
                    </h3>

                    {/* Short Description */}
                    <p className="text-[11px] text-stone-500 line-clamp-2 mt-1">
                      {product.description}
                    </p>
                  </div>

                  {/* Price & Unit */}
                  <div className="pt-2 border-t border-stone-100">
                    <div className="flex items-baseline justify-between mb-2">
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-black text-emerald-700">
                          {product.discountPrice || product.price}
                        </span>
                        <span className="text-xs font-bold text-stone-600">جنيه</span>
                        <span className="text-[11px] text-stone-400">/ {product.unit}</span>
                      </div>
                      {product.discountPrice && (
                        <span className="text-xs text-stone-400 line-through">
                          {product.price} ج
                        </span>
                      )}
                    </div>

                    {/* Quantity Stepper & Add to Cart */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center bg-stone-100 rounded-xl p-1 border border-stone-200">
                        <button
                          onClick={() => handleQuantityChange(product.id, -1)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white text-stone-700 transition"
                          title="تقليل الكمية"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-7 text-center font-bold text-xs text-stone-800">
                          {currentQty}
                        </span>
                        <button
                          onClick={() => handleQuantityChange(product.id, 1)}
                          className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white text-stone-700 transition"
                          title="زيادة الكمية"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={() => handleAddToCart(product)}
                        className="flex-1 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-extrabold shadow-sm hover:shadow transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>أضف للسلة</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 5. QUALITY GUARANTEE BADGE */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-green-700 text-white rounded-3xl p-6 md:p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-amber-400 text-stone-900 rounded-2xl shadow-lg shrink-0">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl md:text-2xl font-black">
              ميثاق الجودة الذهبي لـ {settings.storeName}
            </h3>
            <p className="text-emerald-100 text-xs md:text-sm mt-1 max-w-xl">
              نضمن لك فحص كل ثمرة خضار وفاكهة معقمة وفرز أول، مع سياسة استرجاع فوري مجاني 100% دون أي تكلفة على العميل.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="bg-white/10 px-4 py-2 rounded-xl text-xs font-bold border border-white/20">
            توصيل فوري طازج 🚀
          </span>
          <span className="bg-white/10 px-4 py-2 rounded-xl text-xs font-bold border border-white/20">
            دفع كاش أو إنستاباي 💳
          </span>
        </div>
      </div>

      {/* 6. PRODUCT INSPECTION MODAL */}
      {inspectProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200">
            <div className="relative aspect-video">
              <img
                src={inspectProduct.image}
                alt={inspectProduct.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setInspectProduct(null)}
                className="absolute top-4 left-4 p-2 rounded-full bg-stone-900/60 hover:bg-stone-900 text-white transition"
              >
                <X className="w-5 h-5" />
              </button>

              {inspectProduct.freshnessBadge && (
                <span className="absolute top-4 right-4 bg-emerald-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-md">
                  {inspectProduct.freshnessBadge}
                </span>
              )}
            </div>

            <div className="p-6 space-y-4">
              <div>
                <div className="flex items-center gap-1.5 text-xs text-stone-400 mb-1">
                  <Store className="w-4 h-4 text-emerald-600" />
                  <span>المزرعة الموردة: {inspectProduct.traderName}</span>
                </div>
                <h3 className="text-xl font-black text-stone-900">{inspectProduct.name}</h3>
                <p className="text-sm text-stone-600 mt-2 leading-relaxed">
                  {inspectProduct.description}
                </p>
              </div>

              <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-200">
                <div>
                  <span className="text-xs text-stone-500 block">السعر للوحدة</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-emerald-700">
                      {inspectProduct.discountPrice || inspectProduct.price}
                    </span>
                    <span className="text-xs font-bold text-stone-600">جنيه مصري</span>
                    <span className="text-xs text-stone-400">/ {inspectProduct.unit}</span>
                  </div>
                </div>

                <div className="text-left">
                  <span className="text-xs text-stone-500 block">حالة المخزون</span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    متوفر ({inspectProduct.stock} {inspectProduct.unit})
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    handleAddToCart(inspectProduct);
                    setInspectProduct(null);
                  }}
                  className="flex-1 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>إضافة إلى السلة الآن</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
