import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { UserRole } from '../types';
import {
  Lock,
  Mail,
  Phone,
  User as UserIcon,
  MapPin,
  Store,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  X
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'login' | 'register' | 'forgot';
  onLoginSuccess?: (role: UserRole) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'login',
  onLoginSuccess
}) => {
  const { login, register, requestPasswordReset } = useStore();

  const [activeTab, setActiveTab] = useState<'login' | 'register' | 'forgot'>(defaultTab);

  // Login form states - COMPLETELY BLANK as specifically requested by user for security
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState('');

  // Register form states
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regRole, setRegRole] = useState<'customer' | 'trader'>('customer');
  const [regStoreName, setRegStoreName] = useState('');
  const [regGovernorate, setRegGovernorate] = useState('القاهرة');
  const [regCityOrDistrict, setRegCityOrDistrict] = useState('');
  const [regStreet, setRegStreet] = useState('');
  const [regBuilding, setRegBuilding] = useState('');
  const [regLandmark, setRegLandmark] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState('');

  // Forgot Password state
  const [forgotPhone, setForgotPhone] = useState('');
  const [forgotStatus, setForgotStatus] = useState<{ message: string; isError: boolean } | null>(null);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginSuccess('');

    if (!loginEmail.trim() || !loginPassword.trim()) {
      setLoginError('يرجى إدخال البريد الإلكتروني أو رقم الهاتف وكلمة المرور');
      return;
    }

    const res = login(loginEmail, loginPassword);
    if (res.success && res.user) {
      setLoginSuccess(`أهلاً بك يا ${res.user.name}! جاري تحويلك...`);
      setTimeout(() => {
        onClose();
        if (onLoginSuccess) {
          onLoginSuccess(res.user!.role);
        }
      }, 700);
    } else {
      setLoginError(res.error || 'فشل تسجيل الدخول، تأكد من صحة البيانات');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess('');

    if (!regName.trim() || !regPhone.trim() || !regEmail.trim() || !regPassword.trim()) {
      setRegError('برجاء ملء كافة الحقول الأساسية المطلوبة');
      return;
    }

    if (regRole === 'trader' && !regStoreName.trim()) {
      setRegError('يرجى كتابة اسم المتجر أو المزرعة للتاجر');
      return;
    }

    if (!regCityOrDistrict.trim() || !regStreet.trim()) {
      setRegError('يرجى إدخال العنوان بالتفصيل (الحي والشارع)');
      return;
    }

    const res = register({
      name: regName,
      phone: regPhone,
      email: regEmail,
      password: regPassword,
      role: regRole,
      storeName: regRole === 'trader' ? regStoreName : undefined,
      address: {
        governorate: regGovernorate,
        cityOrDistrict: regCityOrDistrict,
        street: regStreet,
        building: regBuilding,
        landmark: regLandmark
      }
    });

    if (res.success && res.user) {
      setRegSuccess(`تم إنشاء الحساب بنجاح! مرحباً بك في متجر بلدي`);
      setTimeout(() => {
        onClose();
        if (onLoginSuccess) {
          onLoginSuccess(res.user!.role);
        }
      }, 800);
    } else {
      setRegError(res.error || 'حدث خطأ أثناء إنشاء الحساب');
    }
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotStatus(null);

    if (!forgotPhone.trim()) {
      setForgotStatus({ message: 'برجاء كتابة رقم الهاتف المسجل به', isError: true });
      return;
    }

    const res = requestPasswordReset(forgotPhone);
    setForgotStatus({ message: res.message, isError: false });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden border border-emerald-100 flex flex-col max-h-[92vh]">
        {/* Header Tabs */}
        <div className="bg-emerald-800 text-white p-5 relative">
          <button
            onClick={onClose}
            className="absolute left-4 top-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="text-center mb-4">
            <h2 className="text-2xl font-black">بوابة الدخول الموحدة</h2>
            <p className="text-emerald-100 text-xs mt-1">
              متجر بلدي - إدارة، تجار، عملاء، وكباتن
            </p>
          </div>

          <div className="flex bg-emerald-900/50 p-1 rounded-2xl max-w-md mx-auto text-xs md:text-sm font-bold">
            <button
              onClick={() => {
                setActiveTab('login');
                setLoginError('');
              }}
              className={`flex-1 py-2 rounded-xl transition ${
                activeTab === 'login' ? 'bg-white text-emerald-900 shadow-md' : 'text-emerald-200 hover:text-white'
              }`}
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => {
                setActiveTab('register');
                setRegError('');
              }}
              className={`flex-1 py-2 rounded-xl transition ${
                activeTab === 'register' ? 'bg-white text-emerald-900 shadow-md' : 'text-emerald-200 hover:text-white'
              }`}
            >
              حساب جديد
            </button>
            <button
              onClick={() => {
                setActiveTab('forgot');
                setForgotStatus(null);
              }}
              className={`flex-1 py-2 rounded-xl transition ${
                activeTab === 'forgot' ? 'bg-white text-emerald-900 shadow-md' : 'text-emerald-200 hover:text-white'
              }`}
            >
              نسيت كلمة السر
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto">
          {/* TAB 1: LOGIN */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {loginError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs md:text-sm flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}
              {loginSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-xs md:text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <span>{loginSuccess}</span>
                </div>
              )}

              <div>
                <label className="block text-xs md:text-sm font-bold text-stone-700 mb-1">
                  البريد الإلكتروني أو رقم الهاتف
                </label>
                <div className="relative">
                  <Mail className="w-5 h-5 text-stone-400 absolute right-3.5 top-3" />
                  <input
                    type="text"
                    value={loginEmail}
                    onChange={e => setLoginEmail(e.target.value)}
                    placeholder="ادخل بريدك الإلكتروني أو رقم الهاتف (مثال: 010...)"
                    autoComplete="off"
                    className="w-full pr-11 pl-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition text-right"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs md:text-sm font-bold text-stone-700">
                    كلمة المرور
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveTab('forgot')}
                    className="text-xs text-emerald-700 hover:text-emerald-800 font-bold"
                  >
                    نسيت كلمة السر؟
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-5 h-5 text-stone-400 absolute right-3.5 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={e => setLoginPassword(e.target.value)}
                    placeholder="ادخل كلمة المرور الخاصة بحسابك"
                    autoComplete="new-password"
                    className="w-full pr-11 pl-11 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white transition"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3.5 top-3 text-stone-400 hover:text-stone-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-lg transition-all transform active:scale-95 cursor-pointer mt-2 text-sm md:text-base"
              >
                دخول إلى لوحة الحساب
              </button>

              <div className="mt-4 pt-4 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                <span>ليس لديك حساب بعد؟</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('register')}
                  className="text-emerald-700 font-bold hover:underline"
                >
                  إنشاء حساب جديد الآن
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: REGISTER */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              {regError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{regError}</span>
                </div>
              )}
              {regSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-700 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{regSuccess}</span>
                </div>
              )}

              {/* Role Selector */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5">نوع الحساب</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegRole('customer')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                      regRole === 'customer'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/30'
                        : 'border-stone-200 bg-white text-stone-600'
                    }`}
                  >
                    <UserIcon className="w-4 h-4" />
                    <span>عميل / متسوق</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegRole('trader')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                      regRole === 'trader'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/30'
                        : 'border-stone-200 bg-white text-stone-600'
                    }`}
                  >
                    <Store className="w-4 h-4" />
                    <span>تاجر / صاحب مزرعة</span>
                  </button>
                </div>
              </div>

              {regRole === 'trader' && (
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    اسم المحل / المزرعة / النشاط التجاري
                  </label>
                  <input
                    type="text"
                    value={regStoreName}
                    onChange={e => setRegStoreName(e.target.value)}
                    placeholder="مثال: مزارع الوادي الأخضر للخضار الطازج"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الاسم الكامل</label>
                  <input
                    type="text"
                    value={regName}
                    onChange={e => setRegName(e.target.value)}
                    placeholder="الاسم الثلاثي"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">رقم الهاتف</label>
                  <input
                    type="tel"
                    value={regPhone}
                    onChange={e => setRegPhone(e.target.value)}
                    placeholder="مثال: 01012345678"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={e => setRegEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">كلمة المرور</label>
                  <input
                    type="password"
                    value={regPassword}
                    onChange={e => setRegPassword(e.target.value)}
                    placeholder="كلمة مرور قوية"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>

              {/* Detailed Address Fields */}
              <div className="pt-2 border-t border-stone-100">
                <span className="block text-xs font-extrabold text-emerald-900 mb-2 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>العنوان بالتفصيل لسرعة التوصيل</span>
                </span>

                <div className="grid grid-cols-2 gap-2 mb-2">
                  <div>
                    <label className="block text-[11px] text-stone-600 mb-0.5">المحافظة</label>
                    <input
                      type="text"
                      value={regGovernorate}
                      onChange={e => setRegGovernorate(e.target.value)}
                      placeholder="القاهرة / الجيزة..."
                      className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 mb-0.5">المدينة / الحي</label>
                    <input
                      type="text"
                      value={regCityOrDistrict}
                      onChange={e => setRegCityOrDistrict(e.target.value)}
                      placeholder="المعادي / الدقي..."
                      className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <label className="block text-[11px] text-stone-600 mb-0.5">اسم الشارع</label>
                    <input
                      type="text"
                      value={regStreet}
                      onChange={e => setRegStreet(e.target.value)}
                      placeholder="شارع النصر..."
                      className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-stone-600 mb-0.5">رقم العمارة/الشقة</label>
                    <input
                      type="text"
                      value={regBuilding}
                      onChange={e => setRegBuilding(e.target.value)}
                      placeholder="عمارة 10 شقة 4"
                      className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <div className="mt-2">
                  <label className="block text-[11px] text-stone-600 mb-0.5">علامة مميزة (اختياري)</label>
                  <input
                    type="text"
                    value={regLandmark}
                    onChange={e => setRegLandmark(e.target.value)}
                    placeholder="بجوار مسجد / صيدلية كذا..."
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-lg text-xs"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition-all text-sm cursor-pointer mt-2"
              >
                تأكيد وتسجيل الحساب
              </button>
            </form>
          )}

          {/* TAB 3: FORGOT PASSWORD */}
          {activeTab === 'forgot' && (
            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-900 text-xs md:text-sm flex items-start gap-3">
                <HelpCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold">استعادة بيانات الحساب</h4>
                  <p className="mt-1 text-amber-800 text-xs">
                    ادخل رقم الهاتف المسجل به في المتجر، وسيصل إشعار فوري إلى إدارة المنصة والمشرفين لإرسال بيانات تسجيل الدخول مباشرة إليك عبر الواتساب.
                  </p>
                </div>
              </div>

              {forgotStatus && (
                <div
                  className={`p-3 rounded-xl text-xs md:text-sm flex items-center gap-2 ${
                    forgotStatus.isError
                      ? 'bg-red-50 text-red-700 border border-red-200'
                      : 'bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold'
                  }`}
                >
                  {forgotStatus.isError ? (
                    <AlertCircle className="w-5 h-5 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5 shrink-0" />
                  )}
                  <span>{forgotStatus.message}</span>
                </div>
              )}

              <div>
                <label className="block text-xs md:text-sm font-bold text-stone-700 mb-1">
                  رقم الهاتف المسجل
                </label>
                <div className="relative">
                  <Phone className="w-5 h-5 text-stone-400 absolute right-3.5 top-3" />
                  <input
                    type="tel"
                    value={forgotPhone}
                    onChange={e => setForgotPhone(e.target.value)}
                    placeholder="مثال: 01012345678"
                    className="w-full pr-11 pl-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition-all text-sm md:text-base cursor-pointer"
              >
                إرسال طلب الاستعادة للإدارة 📲
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('login')}
                className="w-full text-center text-xs text-stone-500 hover:text-emerald-700 py-1"
              >
                العودة لصفحة تسجيل الدخول
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
