import React from 'react';
import { useStore } from '../context/StoreContext';
import {
  ShoppingBag,
  X,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ShieldCheck,
  Truck
} from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, onCheckout }) => {
  const { cart, removeFromCart, updateCartQuantity, clearCart, getCartTotal, settings } = useStore();
  const { subtotal, deliveryFee, total } = getCartTotal();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-hidden animate-slideLeft">
        {/* Header */}
        <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-700" />
            <h2 className="font-black text-stone-900 text-lg">سلة مشترياتك</h2>
            <span className="bg-emerald-100 text-emerald-800 text-xs px-2 py-0.5 rounded-full font-bold">
              {cart.reduce((s, i) => s + i.quantity, 0)} صنف
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <span className="text-5xl">🛒</span>
              <h3 className="font-bold text-stone-700 text-base">سلة التسوق فارغة</h3>
              <p className="text-xs text-stone-400 max-w-xs">
                تصفح المنتجات وأضف الخضار والفاكهة الطازجة لتصلك لباب البيت بأعلى جودة.
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-5 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold hover:bg-emerald-800 transition cursor-pointer"
              >
                تصفح المنتجات الآن
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between text-xs text-stone-500 pb-2 border-b border-stone-100">
                <span>الأصناف المختارة</span>
                <button
                  onClick={clearCart}
                  className="text-red-600 hover:underline text-[11px] font-semibold"
                >
                  تفريغ السلة بالكامل
                </button>
              </div>

              {cart.map(item => {
                const itemPrice = item.product.discountPrice || item.product.price;
                const itemTotal = itemPrice * item.quantity;

                return (
                  <div
                    key={item.product.id}
                    className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-3 relative group"
                  >
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0 border border-stone-200"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-stone-900 text-xs md:text-sm line-clamp-1">
                        {item.product.name}
                      </h4>
                      <p className="text-[10px] text-stone-400 line-clamp-1">
                        من: {item.product.traderName}
                      </p>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="font-extrabold text-emerald-700 text-sm">
                          {itemTotal} جنيه
                        </span>
                        <span className="text-[10px] text-stone-400">
                          ({itemPrice} ج / {item.product.unit})
                        </span>
                      </div>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex flex-col items-end gap-1.5">
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="text-stone-400 hover:text-red-600 transition p-1"
                        title="حذف الصنف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <div className="flex items-center bg-white rounded-xl border border-stone-200 p-0.5">
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center text-stone-600 hover:bg-stone-100 rounded-lg text-xs"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold text-stone-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center text-stone-600 hover:bg-stone-100 rounded-lg text-xs"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}
        </div>

        {/* Footer & Checkout Summary */}
        {cart.length > 0 && (
          <div className="p-4 border-t border-stone-200 bg-stone-50 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>إجمالي الأصناف:</span>
                <span className="font-bold text-stone-900">{subtotal} جنيه</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>رسوم التوصيل السريع:</span>
                </span>
                <span className="font-bold text-stone-900">{deliveryFee} جنيه</span>
              </div>
              <div className="flex justify-between text-sm font-black text-stone-900 pt-2 border-t border-stone-200">
                <span>المجموع الكلي المطلوب:</span>
                <span className="text-emerald-700 text-base">{total} جنيه</span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 bg-emerald-50 p-2 rounded-xl border border-emerald-100">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>مشمول بضمان الجودة البلدي وسياسة الاسترجاع المجاني الفوري.</span>
            </div>

            <button
              onClick={() => {
                onClose();
                onCheckout();
              }}
              className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-2xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-95 text-sm md:text-base"
            >
              <span>متابعة إتمام الطلب وتحديد الدفع</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
