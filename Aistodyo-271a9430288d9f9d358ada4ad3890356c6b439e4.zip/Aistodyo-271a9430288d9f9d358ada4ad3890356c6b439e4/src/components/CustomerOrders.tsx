import React from 'react';
import { useStore } from '../context/StoreContext';
import {
  Package,
  Bike,
  Phone,
  MessageCircle,
  Clock,
  CheckCircle2,
  AlertCircle,
  Truck,
  MapPin,
  Calendar
} from 'lucide-react';
import { OrderStatus } from '../types';

export const CustomerOrders: React.FC = () => {
  const { orders, currentUser } = useStore();

  // Filter orders for current user
  const userOrders = orders.filter(o => {
    if (currentUser) {
      return o.customerId === currentUser.id || o.customerPhone === currentUser.phone;
    }
    return true; // if guest session, show all recent
  });

  const getStatusStep = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return 1;
      case 'preparing':
        return 2;
      case 'out_for_delivery':
        return 3;
      case 'delivered':
        return 4;
      default:
        return 1;
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
            <Clock className="w-3.5 h-3.5" />
            <span>جديد - بانتظار التأكيد</span>
          </span>
        );
      case 'preparing':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200 animate-pulse">
            <Package className="w-3.5 h-3.5" />
            <span>جاري التجهيز والفرز 📦</span>
          </span>
        );
      case 'out_for_delivery':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-purple-700 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-200">
            <Truck className="w-3.5 h-3.5" />
            <span>خرج للتوصيل مع المندوب 🛵</span>
          </span>
        );
      case 'delivered':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-green-700 bg-green-50 px-2.5 py-1 rounded-full border border-green-200">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>تم التسليم بنجاح ✅</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 text-xs font-bold text-red-700 bg-red-50 px-2.5 py-1 rounded-full border border-red-200">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>ملغي</span>
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-3 bg-emerald-700 text-white rounded-2xl shadow-sm">
          <Package className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-xl md:text-2xl font-black text-stone-900">
            متابعة وتتبع طلباتي
          </h1>
          <p className="text-stone-500 text-xs md:text-sm">
            تحديث لحظي لحالة الطلب وتتبع مندوب التوصيل خطوة بخطوة
          </p>
        </div>
      </div>

      {userOrders.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 space-y-3">
          <span className="text-5xl block">🛵</span>
          <h3 className="text-lg font-bold text-stone-800">لا توجد طلبات مسجلة حتى الآن</h3>
          <p className="text-xs text-stone-400">
            اطلب الآن الخضار والفاكهة الطازجة لتصلك بأسرع وقت مع تتبع مباشر لمندوب التوصيل.
          </p>
        </div>
      ) : (
        <div className="space-y-5">
          {userOrders.map(order => {
            const step = getStatusStep(order.status);

            return (
              <div
                key={order.id}
                className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition space-y-4 p-5 md:p-6"
              >
                {/* Order Top Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-stone-100">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-base md:text-lg font-black text-emerald-800 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200">
                      #{order.orderNumber}
                    </span>
                    <div className="text-xs text-stone-500 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{new Date(order.createdAt).toLocaleDateString('ar-EG')}</span>
                      <span>({new Date(order.createdAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })})</span>
                    </div>
                  </div>

                  <div>{getStatusBadge(order.status)}</div>
                </div>

                {/* Progress Tracker Bar */}
                <div className="py-2">
                  <div className="grid grid-cols-4 gap-2 text-center text-[11px] md:text-xs font-bold text-stone-600 mb-2">
                    <span className={step >= 1 ? 'text-emerald-700' : 'text-stone-400'}>
                      1. جديد
                    </span>
                    <span className={step >= 2 ? 'text-emerald-700' : 'text-stone-400'}>
                      2. جاري التجهيز
                    </span>
                    <span className={step >= 3 ? 'text-emerald-700' : 'text-stone-400'}>
                      3. خرج للتوصيل
                    </span>
                    <span className={step >= 4 ? 'text-emerald-700' : 'text-stone-400'}>
                      4. تم التسليم
                    </span>
                  </div>

                  <div className="h-2.5 bg-stone-100 rounded-full overflow-hidden relative">
                    <div
                      className="h-full bg-emerald-600 rounded-full transition-all duration-700 ease-out"
                      style={{ width: `${(step / 4) * 100}%` }}
                    />
                  </div>
                </div>

                {/* SPECIAL DRIVER ALERT CARD: "المندوب اتحرك، اسمه كذا وتليفونه كذا" */}
                {order.status === 'out_for_delivery' && (
                  <div className="bg-gradient-to-r from-purple-50 via-indigo-50 to-blue-50 border-2 border-purple-300 rounded-2xl p-4 md:p-5 shadow-sm space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-purple-600 text-white rounded-2xl shadow-md">
                        <Bike className="w-6 h-6" />
                      </div>
                      <div>
                        <span className="bg-purple-200 text-purple-900 text-[10px] font-black px-2 py-0.5 rounded-full">
                          إشعار حركة المندوب 🛵
                        </span>
                        <h4 className="text-base md:text-lg font-black text-purple-950 mt-0.5">
                          المندوب اتحرك، وفي الطريق إليك الآن!
                        </h4>
                      </div>
                    </div>

                    <div className="bg-white/80 backdrop-blur-xs p-3.5 rounded-xl border border-purple-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <span className="text-xs text-stone-500 block">اسم مندوب التوصيل:</span>
                        <span className="font-extrabold text-sm md:text-base text-stone-900">
                          {order.driverName || 'مندوب متجر بلدي'}
                        </span>
                      </div>

                      <div className="space-y-0.5">
                        <span className="text-xs text-stone-500 block">رقم هاتف المندوب:</span>
                        <span className="font-mono font-bold text-sm text-purple-900">
                          {order.driverPhone || 'غير متوفر'}
                        </span>
                      </div>

                      {order.driverPhone && (
                        <div className="flex items-center gap-2">
                          <a
                            href={`tel:${order.driverPhone}`}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                          >
                            <Phone className="w-3.5 h-3.5" />
                            <span>اتصال مباشر</span>
                          </a>

                          <a
                            href={`https://wa.me/${(order.driverPhone.startsWith('0') ? '2' + order.driverPhone : order.driverPhone).replace(/\+/g, '')}?text=${encodeURIComponent(`السلام عليكم، أنا العميل صاحب طلب #${order.orderNumber}`)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-green-600 hover:bg-green-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>واتساب المندوب</span>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Items in this order */}
                <div className="space-y-2 pt-2 border-t border-stone-100">
                  <span className="text-xs font-extrabold text-stone-700 block">
                    الأصناف المطلوبة ({order.items.length}):
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {order.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 bg-stone-50 rounded-xl border border-stone-100 flex items-center gap-2.5"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-10 h-10 rounded-lg object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <h5 className="font-bold text-xs text-stone-800 line-clamp-1">{item.name}</h5>
                          <span className="text-[11px] text-stone-500">
                            {item.quantity} {item.unit} × {item.price} ج
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Delivery Address & Financial Summary */}
                <div className="p-3 bg-stone-50 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs text-stone-600">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>
                      {order.customerAddress.governorate} - {order.customerAddress.cityOrDistrict} - {order.customerAddress.street}
                      {order.customerAddress.building ? ` (${order.customerAddress.building})` : ''}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 mr-auto">
                    <span>
                      وسيلة الدفع:{' '}
                      <strong className="text-stone-900">
                        {order.paymentMethod === 'cash'
                          ? 'كاش عند الاستلام'
                          : order.paymentMethod === 'instapay'
                          ? 'إنستاباي'
                          : order.paymentMethod === 'vodafone_cash'
                          ? 'فودافون كاش'
                          : 'بطاقة دفع'}
                      </strong>
                    </span>

                    <span className="text-sm font-black text-emerald-800">
                      الإجمالي: {order.total} جنيه
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
