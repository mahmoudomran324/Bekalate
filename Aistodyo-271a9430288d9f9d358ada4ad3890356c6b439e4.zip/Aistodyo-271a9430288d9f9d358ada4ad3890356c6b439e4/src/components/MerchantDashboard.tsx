import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { audioAlert } from '../utils/audioAlert';
import { Product, ProductCategory, Order } from '../types';
import {
  Store,
  Package,
  Plus,
  Trash2,
  Edit,
  Eye,
  EyeOff,
  Upload,
  Volume2,
  VolumeX,
  CheckCircle2,
  Truck,
  Bike,
  DollarSign,
  AlertTriangle,
  X,
  Phone,
  Search,
  Percent
} from 'lucide-react';

export const MerchantDashboard: React.FC = () => {
  const {
    currentUser,
    orders,
    products,
    updateOrderStatus,
    assignDriverToOrder,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleHideProduct,
    isSirenRinging,
    stopSiren,
    testSiren,
    settings
  } = useStore();

  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'finances'>('orders');

  // Modal for assigning driver when clicking "خرج للتوصيل"
  const [driverModalOrder, setDriverModalOrder] = useState<Order | null>(null);
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [driverDispatchLink, setDriverDispatchLink] = useState('');

  // Modal for Add / Edit Product
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodCategory, setProdCategory] = useState<ProductCategory>('vegetables');
  const [prodPrice, setProdPrice] = useState<number>(20);
  const [prodUnit, setProdUnit] = useState<string>('كجم');
  const [prodStock, setProdStock] = useState<number>(50);
  const [prodImage, setProdImage] = useState<string>('');
  const [prodDescription, setProdDescription] = useState('');
  const [prodBadge, setProdBadge] = useState('فرز أول');
  const [hasOffer, setHasOffer] = useState(false);
  const [prodDiscountPrice, setProdDiscountPrice] = useState<number | undefined>(undefined);
  const [prodOfferBadge, setProdOfferBadge] = useState('عرض خاص بالاتفاق');

  // Filter trader data
  const traderId = currentUser?.id || 'usr_trader_1';
  const traderOrders = orders.filter(o => o.traderIds.includes(traderId));
  const traderProducts = products.filter(p => p.traderId === traderId);

  // Stats calculation
  const totalSales = traderOrders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => {
      const itemsSum = o.items
        .filter(i => i.traderId === traderId)
        .reduce((sub, i) => sub + i.price * i.quantity, 0);
      return sum + itemsSum;
    }, 0);

  const totalOrdersCount = traderOrders.length;
  const platformCommissionTotal = (totalSales * settings.platformCommissionRate) / 100;
  const currentDebt = currentUser?.debt ?? platformCommissionTotal;

  // Alert the merchant with a loud siren when an incoming order has status 'new'
  useEffect(() => {
    const pendingNewOrder = traderOrders.find(o => o.status === 'new');
    if (pendingNewOrder && !isSirenRinging) {
      audioAlert.start(`طلب جديد #${pendingNewOrder.orderNumber}`);
    }
  }, [traderOrders, isSirenRinging]);

  // Handle Driver dispatch modal submit
  const handleConfirmDriver = (e: React.FormEvent) => {
    e.preventDefault();
    if (!driverModalOrder) return;
    if (!driverName.trim() || !driverPhone.trim()) return;

    const whatsappLink = assignDriverToOrder(
      driverModalOrder.id,
      driverName.trim(),
      driverPhone.trim()
    );

    setDriverDispatchLink(whatsappLink);
  };

  // Handle image upload from computer or phone file storage
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setProdImage(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Open product modal for add or edit
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProdName('');
    setProdCategory('vegetables');
    setProdPrice(25);
    setProdUnit('كجم');
    setProdStock(50);
    setProdImage('https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80');
    setProdDescription('');
    setProdBadge('فرز أول');
    setHasOffer(false);
    setProdDiscountPrice(undefined);
    setProdOfferBadge('عرض خاص بالاتفاق مع الإدارة');
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProdName(prod.name);
    setProdCategory(prod.category);
    setProdPrice(prod.price);
    setProdUnit(prod.unit);
    setProdStock(prod.stock);
    setProdImage(prod.image);
    setProdDescription(prod.description);
    setProdBadge(prod.freshnessBadge || 'فرز أول');
    setHasOffer(Boolean(prod.discountPrice && prod.discountPrice < prod.price));
    setProdDiscountPrice(prod.discountPrice);
    setProdOfferBadge(prod.freshnessBadge || 'عرض خاص بالاتفاق مع الإدارة');
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim() || !prodImage) return;

    const discountVal = hasOffer && prodDiscountPrice ? Number(prodDiscountPrice) : undefined;
    const finalBadge = hasOffer ? prodOfferBadge.trim() || 'عرض خاص' : prodBadge.trim();

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        discountPrice: discountVal,
        unit: prodUnit.trim(),
        stock: Number(prodStock),
        image: prodImage,
        description: prodDescription.trim(),
        freshnessBadge: finalBadge
      });
    } else {
      addProduct({
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        discountPrice: discountVal,
        unit: prodUnit.trim(),
        stock: Number(prodStock),
        image: prodImage,
        traderId,
        traderName: currentUser?.storeName || currentUser?.name || 'مزرعة بلدي المعتمدة',
        isHidden: false,
        description: prodDescription.trim() || 'صنف بلدي فرز أول طازج وعالي الجودة.',
        freshnessBadge: finalBadge
      });
    }

    setIsProductModalOpen(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Trader Profile Header */}
      <div className="bg-gradient-to-r from-amber-700 via-amber-600 to-emerald-700 text-white rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3.5 bg-white text-stone-900 rounded-2xl shadow-md">
            <Store className="w-8 h-8 text-amber-700" />
          </div>
          <div>
            <span className="bg-black/20 text-amber-200 text-xs px-2.5 py-0.5 rounded-full font-bold">
              لوحة تحكم التاجر والمزرعة
            </span>
            <h1 className="text-xl md:text-2xl font-black mt-1">
              {currentUser?.storeName || currentUser?.name || 'مزرعة بلدي'}
            </h1>
            <p className="text-amber-100 text-xs mt-0.5">
              هاتف التواصل: {currentUser?.phone} | النطاق: {currentUser?.address?.governorate || 'القاهرة'}
            </p>
          </div>
        </div>

        {/* Audio Alert Controls for Merchant */}
        <div className="flex items-center gap-2">
          {isSirenRinging ? (
            <button
              onClick={stopSiren}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2.5 rounded-xl font-black text-xs md:text-sm shadow-lg flex items-center gap-2 animate-bounce cursor-pointer"
            >
              <VolumeX className="w-5 h-5" />
              <span>إيقاف صوت الجرس 🔔</span>
            </button>
          ) : (
            <button
              onClick={testSiren}
              className="bg-white/20 hover:bg-white/30 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <Volume2 className="w-4 h-4" />
              <span>فحص صوت الإشعار</span>
            </button>
          )}
        </div>
      </div>

      {/* Stats Cards: مبيعاته، عدد الطلبات، المديونية، والعمولات */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs font-semibold mb-1">
            <span>إجمالي المبيعات</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-xl md:text-2xl font-black text-stone-900">{totalSales} جنيه</span>
          <p className="text-[11px] text-stone-400 mt-1">قيمة المشتريات من متجرك</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs font-semibold mb-1">
            <span>عدد الطلبات</span>
            <Package className="w-4 h-4 text-blue-600" />
          </div>
          <span className="text-xl md:text-2xl font-black text-stone-900">{totalOrdersCount} طلب</span>
          <p className="text-[11px] text-stone-400 mt-1">كل العمليات المسجلة</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs font-semibold mb-1">
            <span>عمولات المنصة ({settings.platformCommissionRate}%)</span>
            <Percent className="w-4 h-4 text-purple-600" />
          </div>
          <span className="text-xl md:text-2xl font-black text-purple-800">
            {platformCommissionTotal.toFixed(1)} جنيه
          </span>
          <p className="text-[11px] text-stone-400 mt-1">نسبة التشغيل والإشراف</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs font-semibold mb-1">
            <span>المديونية الحالية</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-xl md:text-2xl font-black text-red-600">
            {currentDebt.toFixed(1)} جنيه
          </span>
          <p className="text-[11px] text-stone-400 mt-1">تصفرها الإدارة بعد التحقق من السداد</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold transition flex items-center gap-2 ${
            activeTab === 'orders'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>إدارة الطلبات الواردة ({traderOrders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold transition flex items-center gap-2 ${
            activeTab === 'products'
              ? 'bg-emerald-700 text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>أصناف متجري والأسعار ({traderProducts.length})</span>
        </button>
      </div>

      {/* TAB 1: ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {traderOrders.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-stone-200">
              <Package className="w-12 h-12 text-stone-300 mx-auto mb-2" />
              <h3 className="font-bold text-stone-700">لا توجد طلبات جديدة حتى الآن</h3>
              <p className="text-xs text-stone-400 mt-1">
                سيتم إطلاق صوت تنبيه عالي فوري عند ورود أي طلب جديد لمتجرك.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {traderOrders.map(order => {
                const traderItems = order.items.filter(i => i.traderId === traderId);
                const orderSubtotal = traderItems.reduce((s, i) => s + i.price * i.quantity, 0);

                return (
                  <div
                    key={order.id}
                    className={`bg-white rounded-3xl border p-5 space-y-4 shadow-xs transition ${
                      order.status === 'new'
                        ? 'border-red-400 bg-red-50/20 ring-2 ring-red-400/30'
                        : 'border-stone-200'
                    }`}
                  >
                    {/* Header */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-stone-100">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-emerald-800 text-base">
                            #{order.orderNumber}
                          </span>
                          {order.status === 'new' && (
                            <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">
                              طلب جديد عاجل 🔔
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-stone-500 mt-0.5">
                          العميل: {order.customerName} - هاتف: {order.customerPhone}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* STEP 1: BUTTON 'جاري التجهيز' - STOPS THE LOUD SIREN! */}
                        {order.status === 'new' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'preparing')}
                            className="bg-amber-400 hover:bg-amber-500 text-stone-900 font-extrabold px-4 py-2 rounded-xl text-xs md:text-sm shadow-md flex items-center gap-1.5 cursor-pointer"
                          >
                            <VolumeX className="w-4 h-4 text-stone-900" />
                            <span>جاري التجهيز (إيقاف الصوت) 📦</span>
                          </button>
                        )}

                        {/* STEP 2: BUTTON 'خرج للتوصيل' - OPENS DRIVER MODAL */}
                        {order.status === 'preparing' && (
                          <button
                            onClick={() => {
                              setDriverModalOrder(order);
                              setDriverName('');
                              setDriverPhone('');
                              setDriverDispatchLink('');
                            }}
                            className="bg-purple-600 hover:bg-purple-700 text-white font-extrabold px-4 py-2 rounded-xl text-xs md:text-sm shadow-md flex items-center gap-1.5 cursor-pointer"
                          >
                            <Bike className="w-4 h-4" />
                            <span>خرج للتوصيل (تحديد المندوب) 🛵</span>
                          </button>
                        )}

                        {/* STEP 3: BUTTON 'تم التسليم' */}
                        {order.status === 'out_for_delivery' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'delivered')}
                            className="bg-green-600 hover:bg-green-700 text-white font-extrabold px-4 py-2 rounded-xl text-xs md:text-sm shadow-md flex items-center gap-1.5 cursor-pointer"
                          >
                            <CheckCircle2 className="w-4 h-4" />
                            <span>تأكيد التسليم بنجاح ✅</span>
                          </button>
                        )}

                        {order.status === 'delivered' && (
                          <span className="bg-green-100 text-green-800 text-xs font-black px-3 py-1 rounded-xl">
                            مكتمل ومسدد
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Items for this trader */}
                    <div className="space-y-1.5">
                      <span className="text-xs font-bold text-stone-600 block">الأصناف المطلوبة من متجرك:</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                        {traderItems.map((item, i) => (
                          <div
                            key={i}
                            className="p-2 bg-stone-50 rounded-xl border border-stone-200 flex items-center gap-2"
                          >
                            <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                            <div className="text-xs">
                              <span className="font-bold text-stone-800 line-clamp-1">{item.name}</span>
                              <span className="text-stone-500 font-semibold">
                                {item.quantity} {item.unit} × {item.price} ج
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Driver details if assigned */}
                    {order.driverName && (
                      <div className="bg-purple-50 p-3 rounded-xl border border-purple-200 text-xs text-purple-900 flex items-center justify-between">
                        <span>
                          المندوب المكلف: <strong>{order.driverName}</strong> ({order.driverPhone})
                        </span>
                        <span className="text-purple-700 font-semibold">تم إشعار العميل بنجاح</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PRODUCTS MANAGEMENT */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base md:text-lg font-black text-stone-900">
                قائمة المنتجات المعروضة بالمتجر
              </h2>
              <p className="text-xs text-stone-500">
                أي منتج تضيفه يظهر فوراً للعملاء مع إمكانية تعديل السعر والكمية في أي لحظة.
              </p>
            </div>

            <button
              onClick={handleOpenAddProduct}
              className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs md:text-sm shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة صنف جديد بالصورة</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {traderProducts.map(product => (
              <div
                key={product.id}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs flex flex-col justify-between"
              >
                <div className="relative aspect-square bg-stone-100">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                  {product.isHidden && (
                    <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center text-white text-xs font-black">
                      مخفي من واجهة العرض
                    </div>
                  )}
                  {product.freshnessBadge && (
                    <span className="absolute top-2 right-2 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {product.freshnessBadge}
                    </span>
                  )}
                </div>

                <div className="p-3.5 space-y-2">
                  <h3 className="font-bold text-sm text-stone-900 line-clamp-1">{product.name}</h3>
                  <div className="flex items-baseline justify-between text-xs">
                    <span className="font-black text-emerald-700 text-base">
                      {product.price} ج <span className="text-[11px] font-normal text-stone-400">/ {product.unit}</span>
                    </span>
                    <span className="text-stone-500 font-semibold">
                      المخزون: {product.stock} {product.unit}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-1">
                    <button
                      onClick={() => handleOpenEditProduct(product)}
                      className="p-1.5 text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition"
                      title="تعديل الصنف"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => toggleHideProduct(product.id)}
                      className="p-1.5 text-stone-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition"
                      title={product.isHidden ? 'إظهار للزبائن' : 'إخفاء مؤقت'}
                    >
                      {product.isHidden ? <EyeOff className="w-4 h-4 text-red-500" /> : <Eye className="w-4 h-4" />}
                    </button>

                    <button
                      onClick={() => deleteProduct(product.id)}
                      className="p-1.5 text-stone-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition"
                      title="حذف الصنف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* DRIVER DISPATCH MODAL: اسم ورقم المندوب */}
      {driverModalOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <Bike className="w-6 h-6 text-purple-600" />
                <h3 className="font-black text-lg text-stone-900">
                  إرسال الطلب مع المندوب
                </h3>
              </div>
              <button
                onClick={() => setDriverModalOrder(null)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-500 leading-relaxed">
              ادخل بيانات مندوب التوصيل ليتم تحويل الطلب لحالة (خرج للتوصيل) وإشعار العميل فوراً: "المندوب اتحرك، اسمه كذا وتليفونه كذا".
            </p>

            {driverDispatchLink ? (
              <div className="p-4 bg-green-50 border border-green-200 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto" />
                <h4 className="font-bold text-green-900 text-sm">تم إسناد الطلب للمندوب بنجاح!</h4>
                <p className="text-xs text-green-800">
                  تم تحديث حالة الطلب وإرسال التنبيه لصفحة العميل.
                </p>
                <a
                  href={driverDispatchLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block py-2 px-4 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold transition"
                >
                  فتح رسالة الواتساب للعميل مباشرة
                </a>
                <button
                  type="button"
                  onClick={() => setDriverModalOrder(null)}
                  className="block w-full py-1 text-stone-500 text-xs hover:underline mt-2"
                >
                  إغلاق النافذة
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmDriver} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    اسم مندوب التوصيل
                  </label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={e => setDriverName(e.target.value)}
                    placeholder="مثال: كابتن محمود الجزار"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    رقم تليفون المندوب
                  </label>
                  <input
                    type="tel"
                    value={driverPhone}
                    onChange={e => setDriverPhone(e.target.value)}
                    placeholder="010xxxxxxxx"
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                    required
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-md transition text-xs md:text-sm cursor-pointer"
                  >
                    تأكيد وإشعار العميل بتحرك المندوب 🛵
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ADD / EDIT PRODUCT MODAL: WITH COMPUTER & PHONE IMAGE UPLOAD */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-black text-lg text-stone-900">
                {editingProduct ? 'تعديل بيانات الصنف' : 'إضافة صنف جديد لمتجرك'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">اسم المنتج</label>
                <input
                  type="text"
                  value={prodName}
                  onChange={e => setProdName(e.target.value)}
                  placeholder="مثال: طماطم بلدي فرز أول..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">القسم</label>
                  <select
                    value={prodCategory}
                    onChange={e => setProdCategory(e.target.value as any)}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                  >
                    <option value="vegetables">خضروات طازجة</option>
                    <option value="fruits">فواكه موسمية</option>
                    <option value="legumes_cheese">بقوليات وجبن بلدي</option>
                    <option value="dried_goods">مجففات وعطارة</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">بادج التميز</label>
                  <input
                    type="text"
                    value={prodBadge}
                    onChange={e => setProdBadge(e.target.value)}
                    placeholder="فرز أول / قطفة اليوم..."
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">السعر (جنيه)</label>
                  <input
                    type="number"
                    value={prodPrice}
                    onChange={e => setProdPrice(Number(e.target.value))}
                    min="1"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الوحدة</label>
                  <input
                    type="text"
                    value={prodUnit}
                    onChange={e => setProdUnit(e.target.value)}
                    placeholder="كجم / طبق..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الكمية المتاحة</label>
                  <input
                    type="number"
                    value={prodStock}
                    onChange={e => setProdStock(Number(e.target.value))}
                    min="0"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>
              </div>

              {/* Special Offer Agreement section */}
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-amber-900">
                  <input
                    type="checkbox"
                    checked={hasOffer}
                    onChange={e => setHasOffer(e.target.checked)}
                    className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                  />
                  <span>تفعيل عرض وتخفيض خاص بالاتفاق مع الإدارة 🏷️</span>
                </label>

                {hasOffer && (
                  <div className="grid grid-cols-2 gap-2 pt-1 animate-fadeIn">
                    <div>
                      <label className="block text-[11px] font-bold text-amber-800 mb-0.5">
                        سعر البيع بعد الخصم (جنيه)
                      </label>
                      <input
                        type="number"
                        value={prodDiscountPrice || ''}
                        onChange={e => setProdDiscountPrice(Number(e.target.value))}
                        placeholder="مثال: 15"
                        min="1"
                        className="w-full px-3 py-1.5 bg-white border border-amber-300 rounded-xl text-xs text-stone-800"
                        required={hasOffer}
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-amber-800 mb-0.5">
                        شارة العرض الترويجية
                      </label>
                      <input
                        type="text"
                        value={prodOfferBadge}
                        onChange={e => setProdOfferBadge(e.target.value)}
                        placeholder="خصم 20% / عرض خاص"
                        className="w-full px-3 py-1.5 bg-white border border-amber-300 rounded-xl text-xs text-stone-800"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* IMAGE UPLOAD FROM COMPUTER OR PHONE */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 flex items-center justify-between">
                  <span>صورة المنتج (رفع من ملفات الجهاز أو الهاتف)</span>
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                </label>

                <div className="flex items-center gap-3">
                  {prodImage && (
                    <img
                      src={prodImage}
                      alt="معاينة"
                      className="w-16 h-16 rounded-xl object-cover border border-stone-300 shrink-0"
                    />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="w-full text-xs text-stone-600 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-800 hover:file:bg-emerald-100 cursor-pointer"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الوصف والمميزات</label>
                <textarea
                  value={prodDescription}
                  onChange={e => setProdDescription(e.target.value)}
                  rows={2}
                  placeholder="اكتب وصفاً جذاباً للصنف وجودته..."
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition text-xs md:text-sm cursor-pointer"
                >
                  {editingProduct ? 'حفظ التعديلات' : 'نشر الصنف في المتجر فوراً'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
