import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldCheck, AlertOctagon, CheckCircle2, RotateCcw, X, Scale } from 'lucide-react';

interface TermsAndQualityModalProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

export const TermsAndQualityModal: React.FC<TermsAndQualityModalProps> = ({ forceOpen, onClose }) => {
  const { settings } = useStore();
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (forceOpen) {
      setIsOpen(true);
      return;
    }
    const hasSeenTerms = localStorage.getItem('baladi_terms_accepted_v1');
    if (!hasSeenTerms) {
      setIsOpen(true);
    }
  }, [forceOpen]);

  const handleAccept = () => {
    localStorage.setItem('baladi_terms_accepted_v1', 'true');
    setIsOpen(false);
    if (onClose) onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-emerald-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-green-700 text-white p-6 relative">
          {onClose && (
            <button
              onClick={() => {
                setIsOpen(false);
                onClose();
              }}
              className="absolute left-4 top-4 p-2 rounded-full bg-white/10 hover:bg-white/20 transition text-white"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-400 text-stone-900 rounded-2xl shadow-md">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <div>
              <span className="bg-emerald-900/60 text-emerald-200 text-xs px-2.5 py-1 rounded-full font-bold">
                ميثاق الشفافية وحماية المشتري
              </span>
              <h2 className="text-xl md:text-2xl font-black mt-1">
                شروط وميثاق الجودة - {settings.storeName}
              </h2>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm md:text-base leading-relaxed text-stone-700">
          <div className="bg-amber-50 border-r-4 border-amber-500 p-4 rounded-xl flex items-start gap-3">
            <AlertOctagon className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-amber-900 text-base">تحذير حاسم من البضاعة التالفة أو غير المطابقة</h4>
              <p className="text-amber-800 text-xs md:text-sm mt-1">
                نحن في متجر بلدي نلزم كافة التجار والمزارعين بفحص المنتجات فرز أول، ويُحظر تماماً توريد أي خضار أو فاكهة أو منتجات مجففة بها تلف أو ذبول.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
              <div className="flex items-center gap-2 text-emerald-800 font-bold mb-1.5">
                <RotateCcw className="w-5 h-5 text-emerald-600" />
                <span>سياسة استرجاع مجانية 100%</span>
              </div>
              <p className="text-stone-600 text-xs leading-relaxed">
                في حال وجود أي ملاحظة على جودة الطلب، يحق للعميل استرجاع الصنف فوراً عند الاستلام واسترداد المبلغ بالكامل دون أي مصاريف شحن إضافية.
              </p>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200">
              <div className="flex items-center gap-2 text-stone-800 font-bold mb-1.5">
                <Scale className="w-5 h-5 text-stone-600" />
                <span>تحميل التاجر كامل المسؤولية</span>
              </div>
              <p className="text-stone-600 text-xs leading-relaxed">
                يتحمل التاجر تكلفة الاسترجاع والتعويض في حال التهاون في الجودة، وتُطبق عليه عقوبة الحظر المؤقت أو الدائم فور تكرار الشكاوى.
              </p>
            </div>
          </div>

          <div className="space-y-2 text-xs md:text-sm text-stone-600 bg-stone-50 p-4 rounded-2xl">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-1" />
              <span>جميع الأسعار موضحة بالجنيه المصري لكل وحدة وزنية أو عددية بكل دقة.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-1" />
              <span>يتم توثيق كل معاملة مالية بسند ورقم قيد رسمي محفوظ في قاعدة البيانات.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-1" />
              <span>إشعار مباشر باسم وتليفون المندوب فور تحركه لضمان أمان وسرعة التسليم.</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <p className="text-xs text-stone-500">
            بالضغط على تأكيد، أنت توافق على الالتزام بميثاق الجودة وشروط المتجر.
          </p>
          <button
            onClick={handleAccept}
            className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold px-6 py-2.5 rounded-xl shadow-md hover:shadow-lg transition cursor-pointer text-sm md:text-base shrink-0"
          >
            موافق وأتعهد بالجودة
          </button>
        </div>
      </div>
    </div>
  );
};
