import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  ShoppingBag,
  User as UserIcon,
  LogOut,
  ShieldCheck,
  Phone,
  LayoutDashboard,
  Store,
  Wallet,
  Package,
  Bike,
  Volume2,
  Menu,
  X,
  FileText
} from 'lucide-react';

interface NavbarProps {
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onNavigate: (view: 'store' | 'merchant' | 'admin' | 'captain' | 'orders' | 'financials') => void;
  currentView: string;
  onOpenTerms: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenCart,
  onOpenAuth,
  onNavigate,
  currentView,
  onOpenTerms
}) => {
  const { currentUser, logout, cart, settings, isSirenRinging, testSiren } = useStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs">
      {/* Top Announcement Bar */}
      <div className="bg-emerald-900 text-emerald-100 text-[11px] md:text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenTerms}
              className="flex items-center gap-1 text-amber-300 hover:text-white font-bold transition"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>ميثاق الجودة: خضار وفاكهة فرز أول وضمان استرجاع مجاني 100%</span>
            </button>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={testSiren}
              className="flex items-center gap-1 text-emerald-200 hover:text-white transition"
              title="تجربة صوت التنبيه العالي"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">فحص نغمة التنبيه</span>
            </button>

            <a
              href={`https://wa.me/${settings.supportWhatsApp.replace(/\+/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-white font-semibold transition"
            >
              <Phone className="w-3 h-3 text-emerald-400" />
              <span>خدمة العملاء: {settings.supportWhatsApp}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Brand & Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('store')}
            className="flex items-center gap-3 text-right group cursor-pointer"
          >
            {settings.storeLogo ? (
              <img
                src={settings.storeLogo}
                alt={settings.storeName}
                className="w-11 h-11 rounded-2xl object-cover shadow-xs border border-emerald-200"
              />
            ) : (
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-600 to-green-700 text-white flex items-center justify-center font-black text-xl shadow-md group-hover:scale-105 transition">
                ب
              </div>
            )}
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl md:text-2xl font-black text-stone-900 group-hover:text-emerald-700 transition">
                  {settings.storeName}
                </span>
                <span className="bg-amber-100 text-amber-800 text-[10px] font-extrabold px-1.5 py-0.5 rounded-full border border-amber-200">
                  بلدي 100%
                </span>
              </div>
              <p className="text-[11px] text-stone-500 line-clamp-1 max-w-[220px] md:max-w-xs">
                {settings.storeSubtitle}
              </p>
            </div>
          </button>
        </div>

        {/* Desktop Quick Nav */}
        <nav className="hidden md:flex items-center gap-1.5">
          <button
            onClick={() => onNavigate('store')}
            className={`px-3 py-1.5 rounded-xl text-sm font-bold transition ${
              currentView === 'store'
                ? 'bg-emerald-50 text-emerald-800'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            المتجر
          </button>

          {currentUser?.role === 'customer' && (
            <>
              <button
                onClick={() => onNavigate('orders')}
                className={`px-3 py-1.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                  currentView === 'orders'
                    ? 'bg-emerald-50 text-emerald-800'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>طلباتي وتتبع المندوب</span>
              </button>

              <button
                onClick={() => onNavigate('financials')}
                className={`px-3 py-1.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                  currentView === 'financials'
                    ? 'bg-emerald-50 text-emerald-800'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                <Wallet className="w-4 h-4 text-emerald-600" />
                <span>الصفحة المالية للمدفوعات</span>
              </button>
            </>
          )}

          {currentUser && (currentUser.role === 'admin' || currentUser.role === 'supervisor') && (
            <button
              onClick={() => onNavigate('admin')}
              className={`px-3 py-1.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                currentView === 'admin'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>لوحة تحكم الإدارة</span>
            </button>
          )}

          {currentUser?.role === 'trader' && (
            <button
              onClick={() => onNavigate('merchant')}
              className={`px-3 py-1.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                currentView === 'merchant'
                  ? 'bg-amber-500 text-stone-900 shadow-xs'
                  : 'bg-amber-50 text-amber-900 hover:bg-amber-100'
              }`}
            >
              <Store className="w-4 h-4" />
              <span>لوحة متجري والطلبات</span>
              {isSirenRinging && (
                <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
              )}
            </button>
          )}

          {/* Captain button: ONLY visible when admin enables the captain system! */}
          {settings.isCaptainSystemEnabled && (
            <button
              onClick={() => onNavigate('captain')}
              className={`px-3 py-1.5 rounded-xl text-sm font-bold transition flex items-center gap-1.5 ${
                currentView === 'captain'
                  ? 'bg-blue-600 text-white'
                  : 'bg-blue-50 text-blue-800 hover:bg-blue-100'
              }`}
            >
              <Bike className="w-4 h-4" />
              <span>بوابة الكابتن</span>
            </button>
          )}
        </nav>

        {/* Action Buttons: Cart & User Auth */}
        <div className="flex items-center gap-2.5">
          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative p-2.5 rounded-2xl bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-700 transition flex items-center gap-2 cursor-pointer"
            title="سلة المشتريات"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="hidden sm:inline text-xs font-bold">السلة</span>
            {cartItemsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                {cartItemsCount}
              </span>
            )}
          </button>

          {/* User Status / Login */}
          {currentUser ? (
            <div className="flex items-center gap-1.5">
              <div className="hidden lg:flex flex-col text-left">
                <span className="text-xs font-black text-stone-800 line-clamp-1">{currentUser.name}</span>
                <span className="text-[10px] text-emerald-700 font-bold">
                  {currentUser.role === 'admin'
                    ? 'مدير النظام'
                    : currentUser.role === 'supervisor'
                    ? currentUser.supervisorTitle || 'مشرف معتمد'
                    : currentUser.role === 'trader'
                    ? currentUser.storeName || 'تاجر معتمد'
                    : currentUser.role === 'captain'
                    ? 'كابتن توصيل'
                    : 'عميل مميز'}
                </span>
              </div>

              <button
                onClick={logout}
                className="p-2.5 rounded-2xl bg-stone-100 hover:bg-red-50 hover:text-red-700 text-stone-600 transition flex items-center gap-1 text-xs font-bold cursor-pointer"
                title="تسجيل الخروج من الحساب"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">خروج</span>
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-4 py-2.5 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs md:text-sm font-extrabold shadow-sm hover:shadow transition flex items-center gap-2 cursor-pointer"
            >
              <UserIcon className="w-4 h-4" />
              <span>دخول / تسجيل</span>
            </button>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-stone-700 hover:bg-stone-100 transition"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-stone-200 bg-white px-4 py-3 space-y-2 animate-fadeIn">
          <button
            onClick={() => {
              onNavigate('store');
              setMobileMenuOpen(false);
            }}
            className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm hover:bg-stone-50"
          >
            المتجر الرئيسي
          </button>

          {currentUser?.role === 'customer' && (
            <>
              <button
                onClick={() => {
                  onNavigate('orders');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm hover:bg-stone-50 flex items-center justify-between"
              >
                <span>طلباتي وتتبع المندوب</span>
                <Package className="w-4 h-4 text-emerald-600" />
              </button>

              <button
                onClick={() => {
                  onNavigate('financials');
                  setMobileMenuOpen(false);
                }}
                className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm hover:bg-stone-50 flex items-center justify-between"
              >
                <span>الصفحة المالية للمدفوعات</span>
                <Wallet className="w-4 h-4 text-emerald-600" />
              </button>
            </>
          )}

          {currentUser && (currentUser.role === 'admin' || currentUser.role === 'supervisor') && (
            <button
              onClick={() => {
                onNavigate('admin');
                setMobileMenuOpen(false);
              }}
              className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm bg-emerald-50 text-emerald-800 flex items-center justify-between"
            >
              <span>لوحة تحكم الإدارة</span>
              <LayoutDashboard className="w-4 h-4" />
            </button>
          )}

          {currentUser?.role === 'trader' && (
            <button
              onClick={() => {
                onNavigate('merchant');
                setMobileMenuOpen(false);
              }}
              className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm bg-amber-50 text-amber-900 flex items-center justify-between"
            >
              <span>لوحة متجري والطلبات</span>
              <Store className="w-4 h-4" />
            </button>
          )}

          {settings.isCaptainSystemEnabled && (
            <button
              onClick={() => {
                onNavigate('captain');
                setMobileMenuOpen(false);
              }}
              className="w-full text-right py-2 px-3 rounded-xl font-bold text-sm bg-blue-50 text-blue-800 flex items-center justify-between"
            >
              <span>بوابة الكباتن والتوصيل</span>
              <Bike className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={() => {
              onOpenTerms();
              setMobileMenuOpen(false);
            }}
            className="w-full text-right py-2 px-3 rounded-xl text-xs text-stone-600 hover:bg-stone-50 flex items-center gap-2"
          >
            <FileText className="w-3.5 h-3.5 text-stone-400" />
            <span>الشروط والأحكام وميثاق الجودة</span>
          </button>
        </div>
      )}
    </header>
  );
};
