import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Order, OrderStatus } from '../types';
import {
  Bike,
  Package,
  MapPin,
  Phone,
  DollarSign,
  CheckCircle2,
  Clock,
  ArrowRight,
  UserCheck,
  AlertCircle
} from 'lucide-react';

export const CaptainDashboard: React.FC = () => {
  const { currentUser, orders, updateOrderStatus, settings } = useStore();

  const [activeTab, setActiveTab] = useState<'available' | 'active' | 'earnings'>('available');

  // Filter orders that are ready for delivery
  const readyOrders = orders.filter(
    o => o.status === 'preparing' || o.status === 'out_for_delivery'
  );

  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  // Calculations for captain earnings
  const deliveryEarningPerOrder = settings.deliveryFee || 20;
  const totalCaptainEarnings = deliveredOrders.length * deliveryEarningPerOrder;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-emerald-700 text-white rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3.5 bg-white text-blue-700 rounded-2xl shadow-md">
            <Bike className="w-8 h-8" />
          </div>
          <div>
            <span className="bg-white/20 text-blue-100 text-xs px-2.5 py-0.5 rounded-full font-bold">
              أسطول مناديب وكباتن متجر بلدي 🛵
            </span>
            <h1 className="text-xl md:text-2xl font-black mt-1">
              بوابة الكابتن - التوصيل السريع
            </h1>
            <p className="text-blue-100 text-xs mt-0.5">
              مرحباً بك {currentUser?.name || 'كابتن بلدي'} - استلم الطلبات من التجار وسلمها للعملاء مباشرة
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/20 text-center">
            <span className="text-[11px] text-blue-200 block">أرباح التوصيل المسددة</span>
            <span className="text-xl font-black text-white">{totalCaptainEarnings} جنيه</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
        <button
          onClick={() => setActiveTab('available')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition flex items-center gap-1.5 ${
            activeTab === 'available'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>طلبات جاهزة للاستلام ({readyOrders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('earnings')}
          className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition flex items-center gap-1.5 ${
            activeTab === 'earnings'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>الصفحة المالية لأرباح التوصيل</span>
        </button>
      </div>

      {/* TAB 1: AVAILABLE / READY ORDERS */}
      {activeTab === 'available' && (
        <div className="space-y-4">
          {readyOrders.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 space-y-2">
              <Package className="w-12 h-12 text-stone-300 mx-auto" />
              <h3 className="font-bold text-stone-700">لا توجد طلبات معلقة بانتظار المندوب حالياً</h3>
              <p className="text-xs text-stone-400">
                بمجرد أن يبدأ أي تاجر في تجهيز طلب، سيظهر هنا للتحرك واستلامه.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {readyOrders.map(order => (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl border border-stone-200 p-5 space-y-4 shadow-xs"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                    <div>
                      <span className="font-mono font-black text-emerald-800 text-base">
                        #{order.orderNumber}
                      </span>
                      <p className="text-xs text-stone-500 mt-0.5">
                        العميل: {order.customerName}
                      </p>
                    </div>

                    <span className="bg-blue-50 text-blue-800 text-xs font-bold px-2.5 py-1 rounded-full border border-blue-200">
                      {order.status === 'preparing' ? 'جاري التجهيز بالمحل' : 'في الطريق للعميل'}
                    </span>
                  </div>

                  {/* Delivery Location */}
                  <div className="space-y-1.5 text-xs text-stone-600 bg-stone-50 p-3 rounded-2xl">
                    <div className="flex items-start gap-1.5 font-bold text-stone-800">
                      <MapPin className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <span>
                        {order.customerAddress.governorate} - {order.customerAddress.cityOrDistrict} - {order.customerAddress.street}
                        {order.customerAddress.building ? ` (${order.customerAddress.building})` : ''}
                      </span>
                    </div>
                    {order.customerAddress.landmark && (
                      <p className="text-[11px] text-stone-500 mr-5">
                        علامة مميزة: {order.customerAddress.landmark}
                      </p>
                    )}
                  </div>

                  {/* Customer phone and actions */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100">
                    <a
                      href={`tel:${order.customerPhone}`}
                      className="inline-flex items-center gap-1.5 text-xs text-emerald-700 font-bold bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>اتصال بالعميل ({order.customerPhone})</span>
                    </a>

                    <div className="flex items-center gap-2">
                      {order.status === 'preparing' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'out_for_delivery')}
                          className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition"
                        >
                          استلمت الطلب وبدأت التحرك 🛵
                        </button>
                      )}

                      {order.status === 'out_for_delivery' && (
                        <button
                          onClick={() => updateOrderStatus(order.id, 'delivered')}
                          className="px-3.5 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>تم التسليم للعميل</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: CAPTAIN EARNINGS & FINANCIAL LEDGER */}
      {activeTab === 'earnings' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <h3 className="font-black text-lg text-stone-900">
                سجل مستحقات التوصيل
              </h3>
              <p className="text-xs text-stone-500">
                قيمة كل مشوار توصيل مكتمل ({deliveryEarningPerOrder} جنيه)
              </p>
            </div>
            <span className="text-lg font-black text-emerald-700 bg-emerald-50 px-4 py-1 rounded-xl">
              إجمالي الأرباح: {totalCaptainEarnings} جنيه
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold">
                <tr>
                  <th className="p-3">رقم الطلب</th>
                  <th className="p-3">اسم العميل</th>
                  <th className="p-3">منطقة التوصيل</th>
                  <th className="p-3">أجرة التوصيل</th>
                  <th className="p-3">الحالة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {deliveredOrders.map(o => (
                  <tr key={o.id} className="hover:bg-stone-50">
                    <td className="p-3 font-mono font-bold text-emerald-800">#{o.orderNumber}</td>
                    <td className="p-3 font-semibold text-stone-800">{o.customerName}</td>
                    <td className="p-3 text-stone-500">{o.customerAddress.cityOrDistrict}</td>
                    <td className="p-3 font-black text-emerald-700">{deliveryEarningPerOrder} جنيه</td>
                    <td className="p-3">
                      <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        مسدد ومكتمل
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
