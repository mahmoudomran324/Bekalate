import React from 'react';
import { useStore } from '../context/StoreContext';
import { Volume2, VolumeX, AlertTriangle, ArrowRight } from 'lucide-react';

interface AudioSirenBannerProps {
  onNavigateToOrders?: () => void;
}

export const AudioSirenBanner: React.FC<AudioSirenBannerProps> = ({ onNavigateToOrders }) => {
  const { isSirenRinging, activeAlertOrder, stopSiren, updateOrderStatus, currentUser } = useStore();

  // Siren alert banner is strictly for merchants, admins, and supervisors — NEVER for customers!
  const isMerchantOrStaff =
    currentUser?.role === 'trader' ||
    currentUser?.role === 'admin' ||
    currentUser?.role === 'supervisor';

  if (!isSirenRinging || !isMerchantOrStaff) return null;

  const handleStopAndPrepare = () => {
    if (activeAlertOrder) {
      updateOrderStatus(activeAlertOrder.id, 'preparing');
    } else {
      stopSiren();
    }
  };

  return (
    <div className="bg-red-600 text-white shadow-xl border-b-4 border-red-800 sticky top-0 z-50 animate-siren">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white text-red-600 rounded-full animate-bounce shadow">
            <Volume2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-white/20 px-2 py-0.5 rounded text-xs font-bold tracking-wide">
                تنبيه فوري عالي الصوت 🔔
              </span>
              <h3 className="font-black text-lg md:text-xl">
                يوجد طلب جديد وارد الآن! {activeAlertOrder ? `#${activeAlertOrder.orderNumber}` : ''}
              </h3>
            </div>
            <p className="text-red-100 text-xs md:text-sm mt-0.5">
              {activeAlertOrder
                ? `العميل: ${activeAlertOrder.customerName} - الإجمالي: ${activeAlertOrder.total} جنيه`
                : 'طلب شراء جديد يحتاج للمراجعة والتأكيد الفوري'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 mr-auto sm:mr-0">
          <button
            onClick={handleStopAndPrepare}
            className="bg-amber-400 hover:bg-amber-300 text-stone-900 font-extrabold px-5 py-2.5 rounded-xl shadow-lg transition-all transform hover:scale-105 active:scale-95 flex items-center gap-2 text-sm md:text-base cursor-pointer"
          >
            <VolumeX className="w-5 h-5 text-stone-900" />
            <span>إيقاف الصوت والبدء في التجهيز 📦</span>
          </button>

          {onNavigateToOrders && (
            <button
              onClick={() => {
                onNavigateToOrders();
              }}
              className="bg-white/20 hover:bg-white/30 text-white px-3 py-2 rounded-xl text-xs md:text-sm font-semibold flex items-center gap-1 transition"
            >
              <span>عرض تفاصيل الطلب</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180" />
            </button>
          )}

          <button
            onClick={stopSiren}
            title="كتم الصوت"
            className="p-2 hover:bg-white/20 rounded-lg text-white/80 hover:text-white transition"
          >
            <VolumeX className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
